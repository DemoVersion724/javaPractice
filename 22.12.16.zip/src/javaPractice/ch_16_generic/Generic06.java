package javaPractice.ch_16_generic;

class MyClass<T, V>{
	//제네릭을 사용하는 sum() 메서드 작성
	void sum(T a, V b ){
		System.out.println(a);
		System.out.println(b);
	}
}

public class Generic06 {

	public static void main(String[] args) {
		int a = 10, b = 20;
		float c = 11.1f, d = 12.1f;
		
		MyClass mc = new MyClass();
		mc.sum(a, b);
		mc.sum(c, d);
	}

}
