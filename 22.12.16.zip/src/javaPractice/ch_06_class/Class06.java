package javaPractice.ch_06_class;

public class Class06 {

	public static void main(String[] args) {
		Class05_tv t; //Class05_tv 인스턴스를 참조하기 위한 변수 t를 선언
		t = new Class05_tv(); //Class05_tv 인스턴스를 생성한다
		t.channel = 7; //Class05_tv 인스턴스의 멤버변수 channel의 값을 7로 한다
		t.channelDown(); //Class05_tv 인스턴스의 메서드 channelDown()를 호출한다
		System.out.println("현재 채널은 " + t.channel + " 입니다"); //현재 채널은 6 입니다
	}

}
