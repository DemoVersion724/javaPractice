package javaPractice.ch_06_class;

public class Class30_singleton {

	public static void main(String[] args) {
		//생성자의 접근제한자가 private여서 실행이 안됨
		//Clsss30_singleton singleton1 = new Clsss30_singleton(); //컴파일 에러
		//Clsss30_singleton singleton2 = new Clsss30_singleton(); //컴파일 에러
		
		Class29_singleton singleton1 = Class29_singleton.getInstance();
		Class29_singleton singleton2 = Class29_singleton.getInstance();
		
		if(singleton1 == singleton2) {
			System.out.println("같은 Clsss30_singleton 객체입니다");
		}
		else {
			System.out.println("다른 Clsss30_singleton 객체입니다");
		}
		
	}

}
