package javaPractice.ch_06_class;

public class Class12 {

	public static void main(String[] args) {
		//멤버 변수로 접근하는 방법은 1)바로 접근 2)메서드를 통한 접근이 가능. 일반적으로 메서드를 통한 접근을 사용
		Class10_Student stydent1 = new Class10_Student();
		//stydent1.studentName = "안연수";
		stydent1.setStudentName("안연수");
		System.out.println(stydent1.getStudentName()); //안연수
		
		Class10_Student stydent2 = new Class10_Student();
		//stydent1.studentName = "홍길동";
		stydent2.setStudentName("홍길동");
		System.out.println(stydent2.getStudentName()); //홍길동
	}

}
