package javaPractice.ch_06_class;

import java.util.Scanner;

public class Class39_Account {
	
	private static Class38_Account[] accountArray = new Class38_Account[100];
	private static Scanner input = new Scanner(System.in);
	
	//계좌 생성하기
	private static void createAccount() {
		System.out.println("------------");
		System.out.println("계좌생성");
		System.out.println("------------");
		
		System.out.println("계좌번호");
		String ano = input.nextLine();
		
		System.out.println("계좌주");
		String owner = input.nextLine();
		
		System.out.println("초기입금액");
		int balance = input.nextInt();
		
		Class38_Account newAccount = new Class38_Account(ano, owner, balance);
		for (int i = 0; i < accountArray.length; i++) {
			if(accountArray[i] == null) {
				accountArray[i] = newAccount;
				System.out.println("결과 : 계좌가 생성되었습니다");
				break;
			}
		}
	}
	
	//계좌목록
	private static void accountList() {
		for (int i = 0; i < accountArray.length; i++) {
			Class38_Account account = accountArray[i];
			if(account != null) {
				System.out.println(account.getAno());
				System.out.println("     ");
				System.out.println(account.getOwner());
				System.out.println("     ");
				System.out.println(account.getBalance());
				System.out.println("     ");
			}
			else {
				break;
			}
		}
	}

	//예금하기
	private static void deposit() {
		//findAccount()호출해서 사용
		System.out.println("------------");
		System.out.println("예금");
		System.out.println("------------");
		System.out.print("계좌번호 : ");
		String ano = input.nextLine();
		System.out.print("예금액 : ");
		int money = input.nextInt();
		Class38_Account account = findAccount(ano);
		if(ano == null) {
			System.out.println("결과 : 계좌가 없습니다");
			return;
		}
		account.setBalance(account.getBalance() + money);
		System.out.println("결과 : 예금에 성공했습니다");
	}

	//출금하기
	private static void withdraw() {
		//findAccount()호출해서 사용
		System.out.println("------------");
		System.out.println("출금");
		System.out.println("------------");
		System.out.print("계좌번호 : ");
		String ano = input.nextLine();
		System.out.print("출금액 : ");
		int money = input.nextInt();
		Class38_Account account = findAccount(ano);
		if(ano == null) {
			System.out.println("결과 : 계좌가 없습니다");
			return;
		}
		if(account.getBalance() < money) {
			System.out.println("결과 : 출금금액이 잔액보다 커서 실패하였습니다");
			return;
		}
		account.setBalance(account.getBalance() - money);
		System.out.println("결과 : 출금에 성공했습니다");
	}
	
	//Account 배열에서 ano와 동일한 Account 객체 찾기
	private static Class38_Account findAccount(String ano) {
		Class38_Account account = null;
		for (int i = 0; i < accountArray.length; i++) {
			if(accountArray[i] != null) {
				String dbAno = accountArray[i].getAno();
				if(dbAno.equals(ano)) {
					account = accountArray[i];
					break;
				}
			}
			else { //null 값이 저장된 경우에는 더 이상 순화할 필요없음
				break;
			}
		}
		return account;
	}
	
	public static void main(String[] args) {
		boolean run = true;
		while (run) {
			System.out.println("-------------------------------------------------------");
			System.out.println("1.계좌생성 | 2.계좌목록 | 3.예금 | 4.출금 | 5.종료");
			System.out.println("-------------------------------------------------------");
			System.out.print("선택>>");
			
			int selsctNo = input.nextInt(); 
			
			if(selsctNo == 1) {
				createAccount();
			} else if(selsctNo == 2) {
				accountList();
			} else if(selsctNo == 3) {
				deposit();
			} else if(selsctNo == 4) {
				withdraw();
			} else if(selsctNo == 5) {
				run = false;
				System.out.println("종료되었습니다");
			}
			
		}
	}
}
