package javaPractice.ch_06_class;

public class Class34_Song {
	/*다중 생성자
	노래 한곡을 나타내는 클래스 Song를 작성하라
	조건 : this를 사용하라
	Song 클래스는 다음과 같이 정의 된다
	#필드
	title : 노래의 제목
	artist :  가수
	length : 곡의 길이 (단위 : 초)*/
	
	public String title, artist;
	public int length;
	
	public Class34_Song() {
	}
	
	public Class34_Song(String title) {
		this.title = title;
	}
	
	public Class34_Song(String title, String artist) {
		this(title);
		this.artist = artist;
	}
	
	public Class34_Song(String title, String artist, int length) {
		this(title, artist);
		this.length = length;
	}
	
	public String toString() {
		return "Song {title : " + title + ", artist : " + artist + ", length : " + length + "}"; 
	}

	public static void main(String[] args) {
		Class34_Song song1 = new Class34_Song("Outward Bound", "Nana", 180);
		Class34_Song song2 = new Class34_Song("Outward Bound", "Nana");
		Class34_Song song3 = new Class34_Song("YesterDay");
		Class34_Song song4 = new Class34_Song();
		
		System.out.println(song1); //Song {title : Outward Bound, artist : Nana, length : 180}
		System.out.println(song2); //Song {title : Outward Bound, artist : Nana, length : 0}
		System.out.println(song3); //Song {title : YesterDay, artist : null, length : 0}
		System.out.println(song4); //Song {title : null, artist : null, length : 0}
	}

}
