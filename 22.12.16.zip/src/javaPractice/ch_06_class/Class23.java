package javaPractice.ch_06_class;

class MyMaths{ //가시성을 위해 새로운 class생성(같은 패키지 내에서 클래스명이 같은 클래스 생성 불가)
	int add(int a, int b) {
		return a + b;
	}
	
	long add(long a, int b) {
		return a + b;
	}
	
	long add(int a, long b) {
		return a + b;
	}
	
	long add(long a, long b) {
		return a + b;
	}

	int add(int[] a) {
		int result = 0;
		for (int i = 0; i < a.length; i++) {
			result += a[i];
		}
		return result;
	}
}

public class Class23 {

	public static void main(String[] args) {
		MyMaths mm = new MyMaths();
		System.out.println("mm.add(3,3) 결과 : " + mm.add(3,3));
		//int add(int a, int b) - mm.add(3,3) 결과 : 6
		
		System.out.println("mm.add(3L,3) 결과 : " + mm.add(3L,3));
		//int add(long a, int b) - mm.add(3L,3) 결과 : 6

		System.out.println("mm.add(3,3L) 결과 : " + mm.add(3,3));
		//int add(int a, long b) - mm.add(3,3L) 결과 : 6

		System.out.println("mm.add(3L,3L) 결과 : " + mm.add(3,3));
		//int add(long a, long b) - mm.add(3L,3L) 결과 : 6
		
		int[] a = {100, 200, 300};
		System.out.println("mm.add(a) 결과 : " + mm.add(a));
		//int add(int[] a) - mm.add(a) 결과 : 600;


	}

}
