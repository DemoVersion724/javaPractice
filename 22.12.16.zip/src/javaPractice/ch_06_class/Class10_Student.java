package javaPractice.ch_06_class;

public class Class10_Student {
	int studentID; //학번
	String studentName; //이름
	int grade; //학번
	String address; //주소
	
	public void showStudentInfo() { //저장된 이름, 주소를 알려줌
		System.out.println(studentName + "," + address);
	}
	//Getter
	public String getStudentName() { //studentName을 반환
		return studentName;
	}
	//Setter
	public void setStudentName(String studentName) { //studentName을 저장
		this.studentName = studentName;
	}
}
