package javaPractice.ch_06_class;

class MyMath{
	int result1, result2, result3;
	double result4;
	
	int add(int a, int b) {
		return a + b;
	}
	int subtract(int a, int b) {
		return a - b;
	}
	int multiply(int a, int b) {
		return a * b;
	}
	double divide(double a, double b) {
		return a / b;
	}

	
}

public class Class22 {

	public static void main(String[] args) {
		//클래스 매서드 수정전
		MyMath mm = new MyMath();
				
	}

}
