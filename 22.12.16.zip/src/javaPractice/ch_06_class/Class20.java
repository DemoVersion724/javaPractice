package javaPractice.ch_06_class;

class Printers{ //가시성을 위해 새로운 class생성(같은 패키지 내에서 클래스명이 같은 클래스 생성 불가)
	static void println(int value) {
		System.out.println(value);
	}
	
	static void println(Boolean value) {
		System.out.println(value);
	}

	static void println(Double value) {
		System.out.println(value);
	}

	static void println(String value) {
		System.out.println(value);
	}

}

public class Class20 {

	public static void main(String[] args) {
	//이전 문제에서 Printer 클래스를 생성하고 println() 메서드를 생성했다 Printer 객체를 생성하지 않고 아래와 같이 호출 할수 있도록 Printer 클래스를 수정하라
		Printers.println(10);
		Printers.println(true);
		Printers.println(5.7);
		Printers.println("홍길동");
		
	}

}
