package javaPractice.ch_06_class;

public class Class11 {

	public static void main(String[] args) {
		Class10_Student stydentAhn = new Class10_Student();
		stydentAhn.studentName = "안승연";
		
		//같은 결과가 나옴
		System.out.println(stydentAhn.studentName); //안승연
		System.out.println(stydentAhn.getStudentName()); //안승연

	}

}
