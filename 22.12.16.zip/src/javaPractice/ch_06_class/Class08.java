package javaPractice.ch_06_class;

public class Class08 {

	public static void main(String[] args) {
		//참조 변수의 복사
		Class05_tv t1 = new Class05_tv();
		Class05_tv t2 = new Class05_tv();
		System.out.println("t1.toString() 값은 " + t1.toString() + " 입니다"); //javaPractice.ch_06_class.Class05_tv@6f2b958e
		System.out.println("t2.toString() 값은 " + t2.toString() + " 입니다"); //javaPractice.ch_06_class.Class05_tv@5e91993f
		System.out.println("t1.channel() 값은 " + t1.channel + " 입니다"); //0
		System.out.println("t2.channel() 값은 " + t2.channel + " 입니다"); //0
		System.out.println();
		
		t1.channel = 7; //channel 값을 7으로 한다
		System.out.println("t1의 channel값을 7로 변경하였습니다");
		System.out.println("t1의 channel값은 " + t1.channel + " 입니다"); //7
		System.out.println("t2의 channel값은 " + t2.channel + " 입니다"); //0
		System.out.println();
		
		t1 = t2; //t1이 저장한 주소값을 t2에 저장. 참조변수라서 동일한 주소를 가르킴
		System.out.println("t1.toString() 값은 " + t1.toString() + " 입니다"); //javaPractice.ch_06_class.Class05_tv@5e91993f
		System.out.println("t2.toString() 값은 " + t2.toString() + " 입니다"); //javaPractice.ch_06_class.Class05_tv@5e91993f
		
		System.out.println("t1.channel() 값은 " + t1.channel + " 입니다"); //0
		System.out.println("t2.channel() 값은 " + t2.channel + " 입니다"); //0
		System.out.println();

		t1.channel = 27; //channel 값을 7으로 한다
		System.out.println("t1의 channel값을 27로 변경하였습니다");
		System.out.println("t1의 channel값은 " + t1.channel + " 입니다"); //27
		System.out.println("t2의 channel값은 " + t2.channel + " 입니다"); //27

	}

}
