package javaPractice.ch_06_class;

public class Class37_getter_setter {
//setter : 클래스 외부에서 값을 받아서 멤버 변수에 저장 return type은 void 매개변수는 수정할 멤버변수와 같은 type이어야함 이름 앞에 set를 붙이고 뒤에는 수정할 멤버변수 이름
//getter : 클래스 외부에 멤버변수의 값을 전달(반환) return type은 참조할 멤버변수의 자료형과 일치. 매개변수는 필요없음 이름 앞에 get를 붙이고 뒤에는 리턴할 멤버변수 이름
//getter , setter 생성할것
	
	private String name;
	private int age;
	private short grade;
	private double avg;
	private int[] numArr;
	
	public String getName(String name) {
		return name;
	}
	public int getAge(int age) {
		return age;
	}
	public short getGrade(short grade) {
		return grade;
	}
	public double getAvg(double avg) {
		return avg;
	}
	public int[] getNumArr() {
		return numArr;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public void setGrade(short grade) {
		this.grade = grade;
	}
	public void setAvg(double avg) {
		this.avg = avg;
	}
	public void setNumArr(int[] numArr) {
		this.numArr = numArr;
	}

}
