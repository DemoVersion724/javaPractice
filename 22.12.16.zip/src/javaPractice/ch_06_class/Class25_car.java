package javaPractice.ch_06_class;

public class Class25_car {
		String color; //색상
		String gearType; //변속기 종류 - auto(자동), manual(수동)
		int door; //문의 개수
		
		Class25_car(){
			this("white","auto",4);
		}
		
		Class25_car(String color){
			this(color,"auto",4);
		}
		
		Class25_car(String color, String gearType, int door){
			this.color = color;
			this.gearType = gearType;
			this.door = door; 
		}

}
