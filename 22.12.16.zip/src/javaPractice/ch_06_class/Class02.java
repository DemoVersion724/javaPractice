package javaPractice.ch_06_class;

public class Class02 {
	//이전 예제에서 만들어진 Car class사용
	public static void main(String[] args) {
		Car mycar; //클래스의 객체를 참조할 수 있는 참조변수 선언
		mycar = new Car(); //클래스의 객체를 생성하고 객체의 주소를 참조변수에 저장
		//Car mycar = new Car(); 같은의미
		System.out.println("시동 처음 초기화 : " + mycar.powerOn); //false
		System.out.println("차의 색상 초기화 : " + mycar.color); //null
		System.out.println("바퀴의 수 초기화 : " + mycar.wheel); //0
		System.out.println("속력 초기화 : " + mycar.speed); //0
		System.out.println("와이퍼 작동 초기화 : " + mycar.wiperOn); //false
		
		mycar.power(); //시동메서드 실행
		System.out.println("시동 메서드 동작 : " + mycar.powerOn); //true
		mycar.power(); //시동메서드 실행
		System.out.println("시동 메서드 다시 동작 : " + mycar.powerOn); //false
		
		mycar.color = "black"; //색상변수에 black 대입
		System.out.println("현재 차의 색상 : " + mycar.color); //black
	}

}
