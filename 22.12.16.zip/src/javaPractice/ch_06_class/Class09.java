package javaPractice.ch_06_class;

class Student{ //Student클래스
	String name;
	int ban;
	int no;
	int kor;
	int eng;
	int math;
	int history;
	
	int getTotal() {//getTotal메서드
		return kor + eng + math + history;
	}
	float getAverage() {//getAverage메서드
		return (float)this.getTotal() / 4;
	}

}

public class Class09 {

	public static void main(String[] args) {
		Student s = new Student();
		s.name = "홍길동";
		s.ban = 1;
		s.no = 1;
		s.kor = 100;
		s.eng = 60;
		s.math = 76;
		s.history = 50;
		
		System.out.println("이름 : " + s.name);
		System.out.println("총점 : " + s.getTotal());
		System.out.println("평균 : " + s.getAverage());
		
	}

}
