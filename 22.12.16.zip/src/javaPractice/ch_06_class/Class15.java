package javaPractice.ch_06_class;

class Account{
	String name; //계좌명의
	int no, balance; //계좌번호, 예금잔고
}

public class Class15 {

	public static void main(String[] args) {
		//두 사람의 은행계좌 데이터를 취급하는 프로그램
		//어떤 경우에 클래스를 사용하느냐? 이 코드를 기반으로 class 생성
		Account account = new Account();
		account.name = "철수";
		account.no = 123456;
		account.balance = 1000;
		
		Account account2 = new Account();
		account2.name = "영희";
		account2.no = 654321;
		account2.balance = 200;
		
		account.balance -= 200; //철수가 200원을 인출
		account2.balance += 100; //영희가 100원을 예금
		
		System.out.println("철수의 계좌");
		System.out.println("계좌명의 : " + account.name); //철수
		System.out.println("계좌번호 : " + account.no); //123456
		System.out.println("예금잔고 : " + account.balance); //800
		System.out.println();
		System.out.println("영희의 계좌");
		System.out.println("계좌명의 : " + account2.name); //영희
		System.out.println("계좌번호 : " + account2.no); //654321
		System.out.println("예금잔고 : " + account2.balance); //300

	}

}
