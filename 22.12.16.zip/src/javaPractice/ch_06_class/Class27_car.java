package javaPractice.ch_06_class;

public class Class27_car {
		String color; //색상
		String gearType; //변속기 종류 - auto(자동), manual(수동)
		int door; //문의 개수
		
		Class27_car(){
			this("white","auto",4);
		}
		
		Class27_car(Class27_car c){ //인스턴스의 복사를 위한 생성자
			color = c.color;
			gearType = c.gearType;
			door = c.door;
		}

		Class27_car(String color, String gearType, int door) {
			this.color = color;
			this.gearType = gearType;
			this.door = door;
		}
		
		public static void main(String[] arge) {
			Class27_car car1 = new Class27_car();
			Class27_car car2 = new Class27_car(car1); //c1의 복사본 c2를 생성한다
			System.out.println("c1의 color = " + car1.color + ", gearType = " + car1.gearType + ", door = " + car1.door);
			System.out.println("c2의 color = " + car2.color + ", gearType = " + car2.gearType + ", door = " + car2.door);
			
			car1.door = 100; //c1의 인스턴스 변수 door의 값을 변경한다
			System.out.println("c1.door=100; 수행 후");
			System.out.println("c1의 color = " + car1.color + ", gearType = " + car1.gearType + ", door = " + car1.door);
			System.out.println("c2의 color = " + car2.color + ", gearType = " + car2.gearType + ", door = " + car2.door);
		}
}
