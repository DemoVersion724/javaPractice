package javaPractice.ch_06_class;

public class Class07 {

	public static void main(String[] args) {
		Class05_tv t1 = new Class05_tv();
		Class05_tv t2 = new Class05_tv();
		System.out.println("t1의 channel값은 " + t1.channel + "입니다."); //t1의 channel값은 0입니다.
		System.out.println("t1의 channel값은 " + t2.channel + "입니다."); //t1의 channel값은 0입니다.
		
		t1.channel = 7; //channel 값을 7으로 한다
		System.out.println("t1의 channel값은 " + t1.channel + "입니다."); //t1의 channel값은 7입니다.
		System.out.println("t2의 channel값은 " + t2.channel + "입니다."); //t2의 channel값은 0입니다.
	}

}
