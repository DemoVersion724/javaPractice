package javaPractice.ch_06_class;

public class Class35_ShopService {
	/*ShopService 객체를 싱글톤으로 만들려고 한다
	ShopService의 getInstance() 메서드로 싱글턴을 얻을 수 있도록 ShopService 클래스를 작성하라*/
	private static Class35_ShopService singleton = null;
	
	private Class35_ShopService() {}
	
		static Class35_ShopService getInstance() {
			if(singleton == null) {
				singleton = new Class35_ShopService();
			}
				return singleton;
		}
		
	}

