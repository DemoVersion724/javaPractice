package javaPractice.ch_06_class;

class Member {
	String name, ID, password; //이름, 아이디, 패스워드
	int age; //나이
}

public class Class13 {

	public static void main(String[] args) {
	//현실세계의 회원을 Member 클래스를 모델링 하려고 한다. 회원의 데이터로는 이름, 아이디, 패스워드,나이가 있다 이데이터를 가지고 Member 클래스 선언
	// 이름 : name :문자열, 아이디 : ID : 문자열, 패스워드 : password : 문자열, 나이 : age : 정수 
		
	}

}
