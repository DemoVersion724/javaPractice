package javaPractice.ch_06_class;

class Car { //클래스는 대문자로 시작
	boolean powerOn; //시동
	String color; //차량의 색상
	int wheel; //바퀴의 수
	int speed; //속력
	boolean wiperOn; //와이퍼
	
	void power() {
		powerOn = !powerOn; //시동메서드
	}
	void speedUp() {
		speed++; //엑셀메서드
	}
	void speedDown() {
		speed--; //브레이크메서드
	}
	void wiper() {
		wiperOn = !wiperOn; //와이퍼메서드
	}
}

public class Class01 {
	//객체지향 언어 : 현실에 존재하는 사물과 개념들을 소프트웨어적으로 구현하고, 그 구현된 객체들이 상호작용하여 데이터를 처리하는 방식
	//객체지향 언어 특징 1)코드의 재사용성 2)신뢰성 높은 프로그래밍 3)코드 관리의 편리함
	//클래스 : 객체의 설계도와 같은 역할, 클래스에는 객체의 속성과 기능들이 정의 되어 있다
	//인스턴스 : 클래스로 만들어진 형태 (객체와 유사)
	/*클래스의 사용 : 클래스는 구현하고자 하는 객체의 속성과 기능들을 정의하는 설계도 입니다,
	속성을 변수로 나타내고 기능을 메서드(함수)로 나타낸다고 본다면 클래스는 관계있는 변수와 메서드의 집합이라고 볼수있습니다*/
	public static void main(String[] args) {
		
	}

}
