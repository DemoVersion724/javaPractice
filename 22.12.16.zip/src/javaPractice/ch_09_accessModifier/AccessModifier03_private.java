package javaPractice.ch_09_accessModifier;

class User2 {
	private String name;
	private int age;
	public String getAge;
	
	public User2(String name, int age){
		this.name = name;
		this.age = age;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}
}

public class AccessModifier03_private {

	public static void main(String[] args) {
		User2 user1 = new User2("철수", 20); //인스턴스 생성
		User2 user2 = new User2("영희", 19); //인스턴스 생성
		
		System.out.println(user1.getName() + "의 나이는 " + user1.getAge());
		//user2.age = 1000; //에러, 직접적인 접근 불가
		user2.setAge(20);
		System.out.println(user2.getName() + "의 나이는 " + user2.getAge());
	}

}
