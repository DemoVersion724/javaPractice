package javaPractice.ch_09_accessModifier;

/*static 제어자는 변수나 메서드 앞에 붙어서 이 멤버가 클래스 멤버라는 것을 의미 
클래스 멤버는 처음 클래스가 메모리에 로드 될때 생성되기 떄문에 인스턴스를 생성하지않아도 사용가능*/

class StaticPracyice{
	public static int number = 3;
	
	public static void say() {
		System.out.println("인스턴스 생성 없이 사용 가능합니다");
	}
}

public class AccessModifier04_static {
	public static void main(String[] args) {
		System.out.println(StaticPracyice.number);
		StaticPracyice.say();
	}

}
