package javaPractice.ch_09_accessModifier;

public class AccessModifier01 {

	public static void main(String[] args) {
		/*접근제어자 : 외부에서 접근할 수 있는 정도와 범위를 정해줍니다 접근제어자로는 허용 범위가 넓은 순서대로 public, protected, default, private 있습니다
		여기서 default는 아무런 접근제어자를 작성하지 않았을 경우를 말합니다*/
		
		/*public : 접근제한이 없음, protected : 같은 패키지 내에서, 다른 패키지의 자손클래스에서 접근이 가능하다,
		  default : 같은 패키지 내에서만 접근이 가능하다, private : 같은 클래스 내에서만 접근이 가능하다*/
	}

}
