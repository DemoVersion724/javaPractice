package javaPractice.ch_09_accessModifier;

public class AccessModifier05_final {

	public static void main(String[] args) {
		//final : 문자그대로 '종결의' 라는 의미를 가집니다, final이 붙으면 내용이나 값을 변경하지 못하게 됩니다
		
		/*final 변수 : 값을 더이상 변경할 수 없는 상수
		final 메서드 : 내용을 더 이상 변경할 수 없는 메서드, 오버라이딩 불가
		final 클래스 : 내용을 더 이상 변경할 수 없는 클래스, 상속불가*/ 
	}

}
