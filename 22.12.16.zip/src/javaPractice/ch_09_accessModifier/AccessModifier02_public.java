package javaPractice.ch_09_accessModifier;

class User {
	public String name;
	public int age;
	
	User(String name, int age){
		this.name = name;
		this.age = age;
	}
}

public class AccessModifier02_public {

	public static void main(String[] args) {
		User user1 = new User("철수", 20); //인스턴스 생성
		User user2 = new User("영희", 19); //인스턴스 생성
		
		System.out.println(user1.name + "의 나이는 " + user1.age);
		user2.age = 1000;
		System.out.println(user2.name + "의 나이는 " + user2.age);
	}

}
