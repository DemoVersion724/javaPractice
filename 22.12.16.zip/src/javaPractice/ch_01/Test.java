package javaPractice.ch_01;

import java.util.Scanner;

public class Test {
	//문제1
	//프로그램 시작시 계좌의 잔액은 10000원입니다
	//프로그램 실행을 하면 제일 먼저 입금 금액을 한번만 입력 받습니다 "입금 금액을 입력해 주십시요" 라는 문장을 출력하고 입금금액을 입력받습니다
	//입금받은 후 1) 그 금액을 잔액과 더하고 2)문장을 출력하여 입금 금액이 얼마인지 또 잔액이 얼마인지 알려줍니다
	//문장은 입금하신 금액은 ****원이고 잔액은 ****원입니다
	//이후에는 잔액이 0원이 될때 까지 계속 출금금액을 입력받습니다 
	//출금금액을 입력시에는 "출금금액을 입력해주십시요" 라는 문장을 출력하고, 출금금액을 입력받습니다
	//출금 금액을 입력받으면 1)잔액에서 차감처리는 하고 2)출금금액이 얼마이고 잔액이 얼마인지 출력을 합니다
	//문장은 "****원을 출금처리 했고, 잔액은 ****원입니다" 입니다
	//잔액보다 더 많은 금액을 출금하고자 하면 문장을 출력하고, 차감처리를 하지않습니다
	//문장은 "잔액은 ****원인데 출금액 ****원이 더 커서 출금이 안됩니다" 입니다
	//0원이 입력된 경우 문장을 출력하고 차감처리를 하지않습니다 문장은 "0원을 입력하셨습니다. 확인하시고 다시 입력해주십시요" 입니다
	//잔액이 모두 출금되어 0원이 되면 문장을 출력하고 프로그램을 종료합니다 문장은 "잔액이 0원이어서 거래가 종료 됩니다 감사합니다" 입니다	
	//모든 입력은 0이상의 정수만 입력된다고 가정합니다
	public static void main(String[] args) {
		int money = 10000;	//현재금액 10000원	
		Scanner input = new Scanner(System.in);
		
		System.out.print("입금 금액을 입력해 주십시요 >> ");
		int deposit = input.nextInt(); //입금 입력받을 금액		
		money = money + deposit; // 현재금액 + 입금받은 금액
		System.out.println("입금하신 금액은 " + deposit + "원 이고, 잔액은 " + money + "원 입니다.");
		
		System.out.print("출금 금액을 입력해 주십시요 >> ");
		while (money > 0) {
			int withdraw = input.nextInt(); //출금 입력받을 금액
			if(money < withdraw) { //현재 금액 보다 출금 금액이 더 크다면
				System.out.println("잔액은 " + money + "원 인데 출금액 " + withdraw + "원이 더 커서 출금이 안됩니다");
				System.out.print("출금 금액을 입력해 주십시요 >> ");
				continue;
			}
			if(withdraw == 0) { //출금 금액을 0원을 입력했다면
				System.out.println("0원을 입력하셨습니다. 확인 하시고 다시 입력해주십시요");
				System.out.print("출금 금액을 입력해 주십시요 >> ");
				continue;
			}	
			money = money - withdraw; // 현재금액 - 출금한 금액
			System.out.print(withdraw + "원을 출금처리 했고, 잔액은 " + money + "원입니다");
			System.out.print("\n출금 금액을 입력해 주십시요 >> ");
			if(money == 0) { //현재금액이 0원이라면
				System.out.println("잔액이 0원이어서 거래가 종료 됩니다 감사합니다");
				break;
			}			
		} //end while
		
		input.close(); //Scanner close
		
		
	}

}
