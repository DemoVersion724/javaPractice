package javaPractice.problem;

import java.util.Scanner;

//재귀에 대한 이해를 곱는 순수 재귀 메서드

class Resur{
	//순수 재귀 메서드
	static void recur(int n) {
		if(n > 0) {
			recur(n -1);
			System.out.println(n);
			recur(n - 2);
		}
	}
	
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		System.out.print("정수를 입력하세요 : ");
		int x = input.nextInt();
		
		recur(x);
		
		input.close();
	}
	
}


	

	


