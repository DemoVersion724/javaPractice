package javaPractice.ch_18_DesignPattern.singleton;

public class CompanyTest {

	public static void main(String[] args) {
		//4. 외부에서 사용하는 코드 만들기
		//외부클래스에서 Company를 생성할 수 없으므로 static으로 제공되는 getInstance() 메서드 호출
		Company company1 = Company.getInstance();
		Company company2 = Company.getInstance();
		
		System.out.println(company1 == company2); //두 변수가 같은 주소인지 확인
		System.out.println(company1); //javaPractice.ch_18_DesignPattern.Company@626b2d4a
		System.out.println(company2); //javaPractice.ch_18_DesignPattern.Company@626b2d4a
	}

}
