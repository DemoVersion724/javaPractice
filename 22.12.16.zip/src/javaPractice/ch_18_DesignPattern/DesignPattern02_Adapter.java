package javaPractice.ch_18_DesignPattern;

//변환기의 역할은 서로 다른 두 인터페이스 사이에 통신이 가능하게 하는 것
//대표적인 Adapter패턴 : JDBC
class ServiceA{
	void runWoke() {
		System.out.println("work");
	}
}

class ServiceB{
	void runStudy() {
		System.out.println("study");
	}
}

class AdapterServiceA{
	ServiceA serviceA = new ServiceA();
	void runService() {
		serviceA.runWoke();
	}
}

class AdapterServiceB{
	ServiceB serviceB = new ServiceB();
	void runService() {
		serviceB.runStudy();
	}
}

public class DesignPattern02_Adapter {
	
	public static void main(String[] args) {
		//AdapterNo
		ServiceA serviceA = new ServiceA();
		ServiceB serviceB = new ServiceB();
		
		serviceA.runWoke();
		serviceB.runStudy();
		
		//AdapterYes
		AdapterServiceA asa1 = new AdapterServiceA();
		AdapterServiceB asa2 = new AdapterServiceB();
		
		//동일한 메서드 명을 사용할 수 있음
		asa1.runService();
		asa2.runService();
	}

}
