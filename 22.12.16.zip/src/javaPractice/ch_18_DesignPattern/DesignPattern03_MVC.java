package javaPractice.ch_18_DesignPattern;

public class DesignPattern03_MVC {

	public static void main(String[] args) {
		//img/MVC정의.png에서 확인

	}

}
