package javaPractice.ch_18_DesignPattern;

public class DesignPattern01 {

	public static void main(String[] args) {
	//디자인 패턴 : 지금가지 수많은 소프트웨어 개발자들이 오랜세월에 걸쳐 쌓아 온 프로그램 설계 노하우를 집대성 한 것
	}

}
