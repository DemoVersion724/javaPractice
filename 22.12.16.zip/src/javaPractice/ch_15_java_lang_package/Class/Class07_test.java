package javaPractice.ch_15_java_lang_package.Class;

import java.util.HashMap;

/*
Student 클래스를 작성하되, Object의 equals()의 hasCode()를 재정의해서
Studentd의 학번 studentNum 이 같으면 동등 객체가 될 수 있도록 해보세요
Student 클래스의 필드는 다음과 같습니다
hasCode()의 리턴 값은 studentNum 필드 값의 해시코드를 리턴 하도록 하세요

실행결과 : 
1번 학생의 총점 : 95
*/
class Student{
	private String studentNum;
	
	public Student(String studentNum) {
		this.studentNum = studentNum;
	}

	public String getStudentNum() {
		return studentNum;
	}
	
	@Override
	public boolean equals(Object obj) {
		if(obj instanceof Student) { 
			Student student = (Student)obj; 
			if(studentNum.equals(student.getStudentNum())) {
				return true;
			}
		}
		return false;
	}
	@Override
	public int hashCode() {
		return studentNum.hashCode();
	}
	
}
public class Class07_test {

	public static void main(String[] args) {
		//Student 키로 총점을 저장하는 HashMap 객체 생성
		HashMap<Student, String> hashMap = new HashMap<Student, String>();
		
		//new Student("1")의 점수 95를 저장
		hashMap.put(new Student("1"), "95");
		
		String score = hashMap.get(new Student("1"));
		System.out.println("1번의 학생의 총점 : " + score);
	}

}
