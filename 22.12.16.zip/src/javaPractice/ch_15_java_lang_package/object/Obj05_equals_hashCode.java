package javaPractice.ch_15_java_lang_package.object;

class Student{
	
	int studentId;
	String studentName;
	
	public Student(int StudentId, String StudentName) {
		this.studentId = StudentId;
		this.studentName = StudentName;
	}
	
	public String toString() {
		return studentId + ", " + studentName;
	}
	
	//equals() 메서드 재정의. 학번이 같으면 같은 학생으로 재정의
	@Override
	public boolean equals(Object obj) {
		if(obj instanceof Student) { //동일한 클래스의 객체이면
			Student std = (Student)obj; //Student 클래스로 형변환
			if(studentId == std.studentId) //이 객체의 학번과 매개변수로 넘어온 객체의 학번이 같으면 true 반환
				return true;
			else return false;
		}
		return false;
	}
	
	@Override
		public int hashCode() { //해시코드 값으로 학번을 반환하도록 메서드 재정의
			return studentId;
		}
}

public class Obj05_equals_hashCode {
	public static void main(String[] args) {
		
		Student studentLee = new Student(100, "이상원");
		Student studentLee2 = studentLee;
		Student studentsang = new Student(100, "이상원");
		
		//동일한 주소의 두 인스턴스 비교
		if(studentLee == studentLee2)
			System.out.println("studentLee와 studentLee2의 주소는 같습니다");
		else
			System.out.println("studentLee와 studentLee2의 주소는 다릅니다");
		//studentLee와 studentLee2는 동일합니다
		
		//동일인이지만 인스턴스의 주소가 다른경우
		//주소는 다르지만 equals의 결과가 true 인 경우
		if(studentLee == studentsang)
			System.out.println("studentLee와 studentsang의 주소는 같습니다");
		else
			System.out.println("studentLee와 studentsang의 주소는 다릅니다");
		//studentLee와 studentsang의 주소는 다릅니다
		
		if(studentLee.equals(studentsang))
			System.out.println("studentLee와 studentsang은 동일합니다");
		else
			System.out.println("studentLee와 studentsang은 동일하지 않습니다");
		//studentLee와 studentsang은 동일합니다
		
		System.out.println("studentLee의 hashCode : " + studentLee.hashCode()); //studentLee의 hashCode : 100
		System.out.println("studentsang의 hashCode : " + studentsang.hashCode()); //studentsang의 hashCode : 100
		
		System.out.println("studentLee의 실제 주소값 : " + System.identityHashCode(studentLee)); //studentLee의 실제 주소값 : 1651191114
		System.out.println("studentLee의 실제 주소값 : " + System.identityHashCode(studentsang)); //studentLee의 실제 주소값 : 1586600255

	}
}
