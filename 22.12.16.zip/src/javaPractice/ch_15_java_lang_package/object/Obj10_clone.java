package javaPractice.ch_15_java_lang_package.object;

//book1 객체를 book2에 복사할 수 있게 clone() 메서드를 오버라이딩 하라
class Mybook implements Cloneable{
	String title;
	
	public Mybook(String title) {
		this.title = title;
	}
	
	public void setTitle(String title) {
		this.title = title;
	}
	
	public String toString() {
		return title;
	}	
	
	@Override
	protected Object clone() throws CloneNotSupportedException {
		return super.clone();
	}
}

public class Obj10_clone {

	public static void main(String[] args) throws CloneNotSupportedException {
		Mybook book1 = new Mybook("자바");
		Mybook book2;
		book2 = (Mybook)book1.clone();
		System.out.println(book2.title);
	}

}
