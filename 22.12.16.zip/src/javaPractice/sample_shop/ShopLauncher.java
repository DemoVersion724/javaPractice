package javaPractice.sample_shop;

//쇼핑몰을 실행하기 위한 런처 프로그램, IShop 인터페이스를 구현하는 다은 쇼핑몰 클래스도 이곳에
public class ShopLauncher {
	//프로그램 메인
	/*
	1.user을 입력 받아서 사용
	2.상품 필수 정보에 제품코드 추가
	3.sellphone 추가 정보에 제조사 추가
	4.스마트TV에 인치수 추가
	5.제품 종류 별로 개수가 나오도록 -> 저장에 적용? 출력에 적용?
	*/
	public static void main(String[] args) {
		IShop shop = new Myshop(); 
		shop.setTitle("MyShop");
		shop.genUser();
		shop.genProduct();
		shop.start();
	}

}
