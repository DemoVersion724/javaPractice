package javaPractice.sample_shop;

//Product 추상 클래스를 상속받아 구현한 CellPhone 클래스
public class CellPhone extends Product{
	String carrier;
	String company; //제조사
	
	public CellPhone(String pname, int price,String productCode ,String carrier, String company) {
		this.pname = pname;
		this.price = price;
		this.productCode = productCode;
		this.carrier = carrier; 
		this.company = company;
	}
	
	@Override
	public void printExtra() {
		System.out.println("통신사 : " + carrier + ", ");
		System.out.println("제조사 : " + company);
	}

}
