package javaPractice.ch_17_collection;

import java.util.TreeSet;

public class Collection15_TreeSet {

	public static void main(String[] args) { //TreeSet 테스트 하기
		TreeSet<String> treeSet = new TreeSet();
		treeSet.add("홍길동");
		treeSet.add("강감찬");
		treeSet.add("이순신");
		treeSet.add("강감찬");
		
		for (String str : treeSet) {
			System.out.println(str);
		}
		//오름차순으로 정렬이 되어 출력
		//강감찬 이순신 홍길동
		//순서는 없음, 정렬은 가능(영문 : ABC... , 한글 : 가나다...)
	}

}
