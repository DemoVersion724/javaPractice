package javaPractice.ch_17_collection;

import java.util.HashSet;

//출력결과가 다음처럼 나오도록 Member 클래스를 구현하라
//[400:정약용, 100:김유신, 200:강감찬, 300:이순신] 출력순서는 상관없습니다
class Member{
	private String memberID;
	private String name;
	
	public Member(String memberID, String name) {
		this.memberID = memberID;
		this.name = name;
	}
	
	@Override
	public boolean equals(Object obj) {
		if(obj instanceof Member) {
			Member member = (Member)obj;
			if(this.memberID.equals(member.memberID)) {
				return true;
			}
			else 
				return false;
		}
		return false;
	}

	@Override
	public int hashCode() {
		return this.memberID.hashCode();
	}
	
	@Override
	public String toString() {
		return memberID + ":" + name;
	}

}
public class Collection14_HashSet {

	public static void main(String[] args) {
		HashSet<Member> set = new HashSet<Member>();
		set.add(new Member("100", "김유신"));
		set.add(new Member("200", "강감찬"));
		set.add(new Member("300", "이순신"));
		set.add(new Member("400", "정약용"));
		set.add(new Member("100", "홍길동"));
		
		System.out.println(set);
	}

}
