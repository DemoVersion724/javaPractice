package javaPractice.ch_17_collection;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

//HashMap에 아이디(String)와 정수(Integer)가 저장되어 있음
//실행결과와 같이 평균 점수를 출력하고, 최고점수와 최고점수를 받은 아이디를 출력할 것 
public class Collection21_Map {

	public static void main(String[] args) {
		Map<String, Integer> map = new HashMap<>();
		map.put("blue", 96);
		map.put("hong", 86);
		map.put("white", 92);
		
		String name = null; //최고 점수를 받은 아이디 저장
		int maxScore = 0; //최고 점수 저장
		int totalScore = 0; //점수 집계 저장
		
		Iterator<String> entrykey = map.keySet().iterator();
		while (entrykey.hasNext()) {
			String key = entrykey.next();
			Integer thisScore = map.get(key);
			totalScore += thisScore;
			if(maxScore < thisScore) {
				maxScore = thisScore;
				name = key;
			}
		}
		System.out.println("평균 점수 : " + totalScore / map.size());
		System.out.println("최고 점수 : " + maxScore);
		System.out.println("최고 점수를 받은 아이디 : " + name);
	}
}
