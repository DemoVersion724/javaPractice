package javaPractice.ch_17_collection.member;

public class MemberTreeSetTest {

	public static void main(String[] args) {
		MemberTreeSet memberTreeSet = new MemberTreeSet();
		
		//새로운 회원 인스턴스 생성
		Member memberLee = new Member(1001, "이지원"); 
		Member memberSon = new Member(1002, "손민국"); 
		Member memberPark = new Member(1003, "박서원"); 
		
		//TreeSet에 회원추가
		memberTreeSet.addMember(memberLee);
		memberTreeSet.addMember(memberSon);
		memberTreeSet.addMember(memberPark);
		
		memberTreeSet.showAllMember(); //전체회원 출력
		
		Member memberHong = new Member(1003, "홍길동"); //1003 아이디 중복 회원 추가
		memberTreeSet.addMember(memberHong);
		memberTreeSet.showAllMember();
	}

}

