package javaPractice.ch_17_collection.member;

import java.util.LinkedList;

public class MemberLinkedList {
	private LinkedList<Member> linkedList; //LinkedList 선언
	
	public MemberLinkedList() {
		this.linkedList = new LinkedList<Member>(); //Member 형으로 선언한 LinkedList 생성
	}
	
	//회원추가 메서드
	public void addMember(Member member) {
		linkedList.add(member); //회원을 추가
	}
	
	//회원삭제 메서드
	public boolean removeMember(int memberID) {
		//for문
		for (int i = 0; i < linkedList.size(); i++) {
			Member member = linkedList.get(i); //get() 메서드로 회원을 순차적으로 가져옴
			if(member.getMemberID() == memberID) { //회원 아이디와 매개변수가 일치하면
				linkedList.remove(i); //해당회원을 삭제
				return true;
			}
		}
		
		//foreach문
//		for(Member member : linkedList) {
//				if(member.getMemberID() == memberID) { //회원 아이디와 매개변수가 일치하면
//				linkedList.remove(member); //해당회원을 삭제
//				return true;
//			}
//		}
		
		System.out.println(memberID + "가 존재 하지 않습니다"); //반복문을 돌려서 해당아이디를 찾지 못한경우
		return false;
	}
	
	//전체 회원 출력 메서드
	public void showAllMember() { //전체 회원을 출력하는 메서드
		for(Member member : linkedList) {
			System.out.println(member);
		}
		System.out.println();
	}
}
