package javaPractice.ch_17_collection.member;

public class MemberHashMapTest {

	public static void main(String[] args) {
		MemberHashMap memberHashMap = new MemberHashMap();
		
		//새로운 회원 인스턴스 생성
		Member memberLee = new Member(1001, "이지원"); 
		Member memberSon = new Member(1002, "손민국"); 
		Member memberPark = new Member(1003, "박서원"); 
		Member memberHong = new Member(1004, "홍길동"); 
		
		//ArrayList에 회원추가
		memberHashMap.addMember(memberLee);
		memberHashMap.addMember(memberSon);
		memberHashMap.addMember(memberPark);
		
		memberHashMap.showAllMember();

		memberHashMap.removeMember(1004); //회원 아이디(key 값)가 1004인 회원 삭제
		memberHashMap.showAllMember();
	}

}
