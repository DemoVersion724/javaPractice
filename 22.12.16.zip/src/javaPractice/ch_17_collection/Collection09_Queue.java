package javaPractice.ch_17_collection;

import java.util.LinkedList;
import java.util.Queue;

class Message{ //Queue를 이용한 메세지 큐
	public String command;
	public String to;
	
	public Message(String command, String to) {
		this.command = command;
		this.to = to;
	}
}
public class Collection09_Queue {
	//Queue를 이용한 메세지 큐
	public static void main(String[] args) {
	//stack은 class 이지만 Queue은 interface
		
		Queue<Message> messageQueue = new LinkedList<Message>();
		
		//메세지 저장
		messageQueue.offer(new Message("sendMail", "홍길동"));
		messageQueue.offer(new Message("sendSNS", "박성훈"));
		messageQueue.offer(new Message("sendkakaotalk", "홍두께"));
	
		while (!messageQueue.isEmpty()) { //메세지 큐가 비었는지 확인
			Message message = messageQueue.poll(); //메세지 큐에서 1개의 메세지 꺼냄
			switch (message.command) {
			case "sendMail": {
				System.out.println(message.to + "님에게 메일을 보냈습니다");
				break;
			}
			case "sendSNS": {
				System.out.println(message.to + "님에게 SMS을 보냈습니다");
				break;
			}
			case "sendkakaotalk": {
				System.out.println(message.to + "님에게 카카오톡을 보냈습니다");
				break;
			}

			}
		}
		/*홍길동님에게 메일을 보냈습니다
		박성훈님에게 SMS을 보냈습니다
		홍두께님에게 카카오톡을 보냈습니다*/
		
	}

}
