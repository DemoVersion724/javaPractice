package javaPractice.ch_17_collection;

import java.util.LinkedList;

class MyQueue{
	private LinkedList<String> linkedList = new LinkedList<String>();
	
	public void enQueue(String data) {
		linkedList.add(data); //큐의 맨 뒤에 추가
	}
	
	public String deQueue() {
		//큐의 맨 앞에서 꺼냄 (가장 앞 데이터를 꺼냄: LinkedList의 사용이유)
		int len = linkedList.size();
		if(len == 0) {
			System.out.println("큐가 비었습니다");
			return null;
		}
		return (linkedList.remove(0)); //맨앞의 자료 반환하고 배열에서 제거
	}
}
public class Collection08_Queue {

	public static void main(String[] args) {
		MyQueue queue = new MyQueue();
		queue.enQueue("A");
		queue.enQueue("B");
		queue.enQueue("C");
		
		System.out.println(queue.deQueue()); //A
		System.out.println(queue.deQueue()); //B
		System.out.println(queue.deQueue()); //C
	}

}
