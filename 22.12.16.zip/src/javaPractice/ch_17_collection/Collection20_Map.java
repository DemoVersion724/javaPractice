package javaPractice.ch_17_collection;

import java.util.HashMap;
import java.util.Map;

class Students { //학번과 키가 같다면 동일한 키로 인식
	public int sno;
	public String name;
	
	public Students(int sno, String name) {
		this.sno = sno;
		this.name = name;
	}
	
	@Override
		public boolean equals(Object obj) { //학번과 이름이 같다면 true를 반환
			if(obj instanceof Students) {
				Students student = (Students) obj;
				return (sno == student.sno) && (name.equals(student.name));
			}
			else {
				return false;
			}
	}
	
	@Override
		public int hashCode() {
			return sno + name.hashCode();
	}
}

public class Collection20_Map {

	public static void main(String[] args) {
		Map<Students, Integer> map = new HashMap<Students, Integer>();
		
		//학번과 이름이 동일한 Students를 키로 저장
		map.put(new Students(1, "홍길동"), 95);
		map.put(new Students(1, "홍길동"), 95);
		map.put(new Students(1, "박유신"), 85);
		
		System.out.println("총 Entry 수 : " + map.size()); //저장된 총 Map.Entry 수 얻기
	}

}
