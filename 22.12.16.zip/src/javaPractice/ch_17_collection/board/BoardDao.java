package javaPractice.ch_17_collection.board;

import java.util.ArrayList;
import java.util.List;

public class BoardDao {
	//방법1.
	public List<Board> getBoardList() {
		List<Board> boardList = new ArrayList<Board>();
		boardList.add(new Board("제목1", "내용1"));
		boardList.add(new Board("제목2", "내용2"));
		boardList.add(new Board("제목3", "내용3"));
		return boardList;
	}
	
	//방법2.
//	List<Board> boardList = new ArrayList<Board>();
//	public BoardDao() {
//		boardList.add(new Board("제목1", "내용1"));
//		boardList.add(new Board("제목2", "내용2"));
//		boardList.add(new Board("제목3", "내용3"));
//
//	}
//	public List<Board> getBoardList() {
//		return boardList;
//	}
	
}
