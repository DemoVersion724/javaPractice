package javaPractice.ch_17_collection;

import java.util.HashSet;

public class Collection10_HashSet {

	public static void main(String[] args) {
		HashSet<String> hashSet = new HashSet<String>();
		//중복된 값은 하나만 저장
		hashSet.add(new String("임정순"));
		hashSet.add(new String("박현정"));
		hashSet.add(new String("홍연의"));
		hashSet.add(new String("강감찬"));
		hashSet.add(new String("강감찬"));
		
		//중복된 문자열은 제거되고 출력 순서의 입력 순서는 상관없음
		System.out.println(hashSet);
	}

}
