package javaPractice.ch_17_collection;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class Collection11_HashSet {
	//String 객체를 중복 없이 저장하는 HashSet
	public static void main(String[] args) {
		//Set : 중복X, 순서X, 인덱스X
		Set<String> set = new HashSet<String>();
		
		set.add("java");
		set.add("JDBC");
		set.add("Servlet/JSP");
		set.add("java");
		set.add("iBATIS");
		
		//중복된 값이 있으면 한개만 저장
		int size = set.size(); //지정된 객체 수 얻기
		System.out.println("총 객체 수 : " + size);
		
		//foreach문은 사용가능(인덱스 값의 영향을 받지 않기때문)
		System.out.println("foreach 문으로 출력 시작");
		for(String s:set) {
			System.out.println("\t" + s);
		}
		System.out.println();
		
		Iterator<String> iterator = set.iterator(); //반복자 얻기
		while (iterator.hasNext()) { //객체 수많큼 루핑
			String element = iterator.next(); //1개의 객체를 가져옴
			System.out.println("\t" + element);
		}
		
		set.remove("JDBC"); //1개의 객체 삭제
		set.remove("iBATIS"); //1개의 객체 삭제
		
		System.out.println("총 객체 수 : " + set.size());
		
		System.out.println("foreach 문으로 출력 시작");
		for (String s : set) {
			System.out.println("\t" + s);
		}
		System.out.println();
		
		set.clear(); //모든객체를 제거 하고 비움
		if(set.isEmpty()) {
			System.out.println("비어 있음");
		}
		
	}

}
