package javaPractice.ch_17_collection;

public class Collection18_Map {

	public static void main(String[] args) {
		/*
		map 인터페이스
		Map은 기본적으로검색용 자료 구조,
		즉 어떤 key 값을 알고 있을 때 value를 찾기 위한 자료구조
		하나가 아닌 쌍으로 pair으로 되어 있는 자료를 관리하는 메서드들이 선언되어 있음
		key-value 쌍이라고 표현하는데 이 때 키 값은 중복 될 수 없음
		학번과 학생 이름처럼 쌍으로 되어 있는 자료를 관리할 때 사용하면 편리
		*/
	}

}
