package javaPractice.ch_10_polymorphism.car;

public class Test02 {

	public static void main(String[] args) {
		//instanceof 연산자
		//a instanceof B : a는 B의 객체이다
		FireEngine fe = new FireEngine();
		
		if(fe instanceof FireEngine) { //fe는 FireEngine의 객체이다
			System.out.println("This is a FireEngine instance");
		}
		if(fe instanceof Car) { //fe는 Car의 객체이다
			System.out.println("This is a Car instance");
		}
		if(fe instanceof Object) { //fe는 Object의 객체이다
			System.out.println("This is a Object instance");
		}
		System.out.println();
		
		Car polvFe = new Car(); //부모클래스로 객체 생성
		if(polvFe instanceof FireEngine) { 
			System.out.println("");
		}
		System.out.println();
		
		Car car = new Car(); //부모클래스로 객체 생성
		if(car instanceof Car) { //car는 Car의 객체이다
			System.out.println("");
		}
		if(polvFe instanceof Object) { //polvFe는 Object의 객체이다
			System.out.println("");
		}


	}

}
