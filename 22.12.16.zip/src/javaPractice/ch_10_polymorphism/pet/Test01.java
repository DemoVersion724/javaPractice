package javaPractice.ch_10_polymorphism.pet;

public class Test01 {

	public static void main(String[] args) {
		//애완동물 클래스의 이용 예(다형성의 검증)
		//다형성의 오버라이딩
		Pet Kurt;
		Kurt = new Pet("Kurt", "아이"); //
		Kurt.introduce(); //내이름은 Kurt 입니다 주인님은 아이 입니다
		System.out.println();
		
		RobotPet r2d2 = new RobotPet("R2D2","루크");
		r2d2.introduce(); //내이름은 R2D2 입니다 주인님은 루크 입니다
		r2d2.work(0);
		System.out.println();
		
		Pet toy = new RobotPet("toy", "아이2");
		toy.introduce(); //제 이름은 toy 입니다 제 주인 이름은 아이2 입니다
		//toy.work(0); //에러발생
		System.out.println();
		
		Pet p = r2d2;
		p.introduce(); //제 이름은 R2D2 입니다 제 주인 이름은 루크 입니다
		
		System.out.println();
		r2d2.setName("아이로봇");
		r2d2.introduce(); //제 이름은 아이로봇 입니다 제 주인 이름은 루크 입니다
		p.introduce(); //제 이름은 아이로봇 입니다 제 주인 이름은 루크 입니다
		

	}

}
