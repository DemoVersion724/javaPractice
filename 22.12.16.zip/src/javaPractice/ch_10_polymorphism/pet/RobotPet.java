package javaPractice.ch_10_polymorphism.pet;

public class RobotPet extends Pet {

	public RobotPet(String name, String masterName) {
		super(name, masterName);
	}

	@Override
	public void introduce() {
		System.out.println("삐뾰삐 제 이름은 " + name + " 입니다");
		System.out.println("삐뾰삐 제 주인 이름은 " + masterName + " 입니다");
	}
		
	void work(int number) {
		switch (number) {
		case 0: 
			System.out.println("청소");
			break;
		case 1: 
			System.out.println("요리");
			break;
		case 2: 
			System.out.println("빨래");
			break;		
		}
	}
}
