package javaPractice.ch_10_polymorphism;

//정수를 입력받는 생성자를 만들고 모든 과목의 점수를 볼 수 있는 dispaly() 생성

class Scores{
		public int kor;
		public int math;
		public int com;
		public int eng;
		
	public Scores(int kor, int math, int com, int eng) {
		this.kor = kor;
		this.math = math;
		this.com = com;
		this.eng = eng;
	}
	public void display () {
		System.out.println("kor : " + kor + "math : " + math + "com : " + "eng : " + eng);
	}

public class Test06 {

	public static void main(String[] args) {
		Scores score = new Scores(100, 80, 95, 84);
		score.display(); //외부에서 접근가능
	}

}
}
