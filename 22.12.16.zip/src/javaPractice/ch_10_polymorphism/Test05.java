package javaPractice.ch_10_polymorphism;

class Score{
	private int kor;
	public int math;
	public int eng;
	public int com;
		
	public int getKor() {
		return kor;
	}
	public void setKor(int kor) {
		if(kor >= 0 && kor <= 100) {
			this.kor = kor;
		} else {
			System.out.println(kor + "은 올바른 값(0 ~ 100)이 아닙니다");
		}
	}
}

public class Test05 {

	public static void main(String[] args) {
		Score score = new Score();
		//score.kor = -500; //정수를 저장하는데 잘못된 값(마이너스)이 입력됨 , 에러 발생 : 외부에서 접근 불가
		score.setKor(-500);
		System.out.println("국어 점수 : " + score.getKor());
	}

}
