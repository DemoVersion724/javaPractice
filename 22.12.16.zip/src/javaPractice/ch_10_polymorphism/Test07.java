package javaPractice.ch_10_polymorphism;

class Parent{
	int x = 100;
	void method() {
		System.out.println("Parent method");
	}
}

class Child extends Parent{}

public class Test07 {

	public static void main(String[] args) {
		Parent parent = new Parent();
		Child child = new Child();
		
		//참조변수 우선
		System.out.println("p.x = " + parent.x); //p.x = 100
		//오버라이딩 우선
		parent.method();
		
		//참조변수 우선
		System.out.println("C.x = " + child.x); //p.x = 100
		//오버라이딩 우선
		child.method();
	}

}
