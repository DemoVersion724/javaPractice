package javaPractice.ch_10_polymorphism;

public class Polymorphism01 {

	public static void main(String[] args) {
		/*다형성 : 다형성이란 하나의 객체가 여러 가지 타입을 가질 수 있는 것을 의미합니다, 
		  다형성의 정의에 따라 조상 클래스 타입의 참조변수로 자손 클래스 타입의 객체를 참조할 수 있습니다*/
		//부모클래스의 참조변수에서 자손 클래스의 인스턴스를 참조할 떄 주의할 점은 부모 클래스의 참조변수로 참조가 불가능한 멤버가 존재한다는 점입니다
		
	}

}
