package javaPractice.ch_10_polymorphism;

class Employee{
	protected int daseSalary = 3000000; //기본급
	int getSalary() {
		return daseSalary;
	}
}

class Manager extends Employee{
	@Override
	int getSalary() {
		return (daseSalary + 2000000);
	}
}

class Programer extends Employee{
	@Override
	int getSalary() {
		return (daseSalary + 3000000);
	}
}

/*일반 직원은 Employee 클래스로 모델링 한다 Employee 클래스를 상속받아서 관리자를 나타내는 Manager 클래스와 프로그래머를 나타내는 Programer 클래스를 작성한다
Employee 클래스 안에는 월급을 계산하는 getSalary() 메서드가 있다 이 메서드를 Manager클래스와 Programer 클래스에서 각 직급별로 다른 월급을 반환하도록 한다
오버라이딩 할때 Employee 클래스의 daseSalary을 사용하라*/

public class Test01 {

	public static void main(String[] args) {
		Manager manager = new Manager();
		System.out.println("관리자의 월급 : " + manager.getSalary());
		//관리자의 월급 : 5000000
		
		Programer programer = new Programer();
		System.out.println("프로그래머의 월급 : " + programer.getSalary());
		//프로그래머의 월급 : 6000000
	}

}
