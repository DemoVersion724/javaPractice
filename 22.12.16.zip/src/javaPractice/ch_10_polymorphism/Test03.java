package javaPractice.ch_10_polymorphism;

class Ainmal{
	void walk() {
		System.out.println("절을 수 있음");
	}
}

//동물을 나타내는 Ainmal 클래스를 상속받아서 새를 나타내는 bird 클래스를 작성해보자

class Bird extends Ainmal{
	void fly() {
		System.out.println("날을 수 있음");
	}
	void sing() {
		System.out.println("노래 부를 수 있음");
	}
}

public class Test03 {

	public static void main(String[] args) {
		Bird bird = new Bird();
		bird.walk(); //걸을 수 있음
		bird.fly(); //날을 수 있음
		bird.sing(); //노래 부를 수 있음

	}

}
