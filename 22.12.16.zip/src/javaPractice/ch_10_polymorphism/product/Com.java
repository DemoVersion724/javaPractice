package javaPractice.ch_10_polymorphism.product;

public class Com extends Product{
	Com(){
		///조상클래스의 생성자 Product(int price)를 호출한다
		super(200); //Tv의 가격을 100만원으로 한다
	}
	public String toString() {
		return "Com";
	}

}
