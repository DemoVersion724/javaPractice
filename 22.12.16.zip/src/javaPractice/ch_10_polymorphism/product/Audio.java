package javaPractice.ch_10_polymorphism.product;

//새로 추가한 클래스
public class Audio extends Product{
	Audio(){
		super(50);
	}
	public String toString() {
		return "Audio";
	}
}
