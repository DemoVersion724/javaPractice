package javaPractice.ch_10_polymorphism.product;

public class Test {

	public static void main(String[] args) {
		Buyer buyer = new Buyer(); //Buyer인스턴스 생성
		Tv tv = new Tv(); //Tv인스턴스 생성
		Com com = new Com(); //Com인스턴스 생성
		Audio audio = new Audio(); //Audio인스턴스 생성
		buyer.buy(tv);
		buyer.buy(com);
		buyer.buy(audio);
		buyer.summary();
		System.out.println();
		//buyer.refund(com);
		//buyer.summary();
	}

}
