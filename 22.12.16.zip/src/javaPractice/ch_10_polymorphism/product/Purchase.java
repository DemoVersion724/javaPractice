package javaPractice.ch_10_polymorphism.product;

public class Purchase {

	public static void main(String[] args) {
		Buyer buyer = new Buyer(); //Buyer인스턴스 생성
		Tv tv = new Tv(); //Tv인스턴스 생성
		Com com = new Com(); //Com인스턴스 생성
		
		buyer.buy(tv);
		buyer.buy(com);
		
		System.out.println("현재 남은 돈은 " + buyer.money + "만원 입니다");
		System.out.println("현재 보너스는 " + buyer.bonusPoint + "점 입니다");
	}

}
