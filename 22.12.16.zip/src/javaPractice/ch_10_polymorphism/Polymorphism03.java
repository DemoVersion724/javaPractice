package javaPractice.ch_10_polymorphism;

class Animal{
	void breath() {
		System.out.println("숨쉬기");
	}
}

class Lion extends Animal{
	@Override
	public String toString() {
		return "사자";
	}
}

class Rabbit extends Animal{
	@Override
	public String toString() { //동물클래스를 상속한 토끼 클래스
		return "토끼";
	}
}

class Monkey extends Animal{
	@Override
	public String toString() { //동물클래스를 상속한 원숭이 클래스
		return "원숭이";
	}
}

class Zookeeper{ //사육사 클래스
	void feed(Animal animal) { //사자에게 먹이 주는 메서드 ,Object에서 toString을 상속 받았기 떄문 가능
		System.out.println(animal + "에게 고기 주기");
	}
}

public class Polymorphism03 {

	public static void main(String[] args) {
		Animal lion = new Lion(); //Lion 인스턴스 생성
		Zookeeper james = new Zookeeper(); //james라는 이름의 사육사 인스턴스 생성
		james.feed(lion); //jamesrk lion에게 먹이를 줌
		
		Animal rabbit = new Rabbit(); //데이터 타입이 Animal인 rabbit 인스턴스 생성
		james.feed(rabbit); //jamesrk rabbit에게 먹이를 줌
		
		Animal monkey = new Monkey(); //데이터 타입이 Animal인 monkey 인스턴스 생성
		james.feed(monkey); //jamesrk monkey에게 먹이를 줌
	}

}
