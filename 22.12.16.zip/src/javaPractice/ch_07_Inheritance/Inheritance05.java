package javaPractice.ch_07_Inheritance;

class Parent{
	int x = 10;
}

class Child extends Parent{
	void method() {
		System.out.println("x = " + x);
		System.out.println("this.x = " + this.x);
		System.out.println("super.x = " + super.x); //상속받았던 부모클래스에 존재하는 것
	}
}

public class Inheritance05 {

	public static void main(String[] args) {
		Child c = new Child();
		c.method();
		// x = 10

	}

}
