package javaPractice.ch_07_Inheritance.chick;

public class Redchick extends Chick{

}
