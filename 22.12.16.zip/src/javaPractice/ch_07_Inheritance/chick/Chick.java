package javaPractice.ch_07_Inheritance.chick;

public class Chick {
	int x;
	int y;
	
	//생성자
	Chick(){
		x = 100;
		y = 100;
	}
	void display() {System.out.println("병아리");}
	void walk() {System.out.println("걷다");}
	void ppick() {System.out.println("삐약삐약");}
}
