package javaPractice.ch_07_Inheritance.chick;

public class Generalchick extends Chick {

}
