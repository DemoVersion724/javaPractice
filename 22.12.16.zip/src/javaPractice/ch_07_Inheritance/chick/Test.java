package javaPractice.ch_07_Inheritance.chick;

public class Test {

	public static void main(String[] args) {
		Generalchick generalchick = new Generalchick();
		generalchick.display();
		Redchick redchick = new Redchick();
		redchick.display();
		System.out.println(redchick.x);
	}

}
