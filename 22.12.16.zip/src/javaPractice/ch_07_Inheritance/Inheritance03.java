package javaPractice.ch_07_Inheritance;

public class Inheritance03 {

	public static void main(String[] args) {
		//자바에서는 단일 상속만을 허용합니다 
		//class Test extends B, extends C{} : 에러발생, 다중상속 불가
	}

}
