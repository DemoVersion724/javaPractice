package javaPractice.ch_07_Inheritance;

public class Inheritance01 {

	public static void main(String[] args) {
		/*상속이란 새로운 클래스를 작성할 때 기존에 존재하는 클래스를 물려받아 이용합니다 
		  기존의 클래스가 가진 멤버를 물려받기 때문에 새롭게 할 코드의 양이 줄어드는 효과가 있습니다
		  이때 자신의 멤버를 물려주는 클래스를 부모 클래스 또는 조상클래스 라고 하고 상속벋는 클래스를 자식 클래스 또는 자손클래스라고 합니다*/
		
		/*class Parents{} //부모클래스를 확인 했을때 자식클래스 여부를 알기쉽지 않지만 자식클래스를 확인하면 알수있음
		class Child extends Parents{} //Parents클래스의 멤버들을 상속받음(생성자는 상속X)*/
	}

}
