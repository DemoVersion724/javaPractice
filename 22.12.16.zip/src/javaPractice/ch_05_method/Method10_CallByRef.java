package javaPractice.ch_05_method;

public class Method10_CallByRef {
	/*참조에 의한 호출 방식
	1.매개변수의 타입이 참조형 타입일 때 사용
	2.참조에 의한 호출은 메서드 호출 시 참조 데이터의 위치가 매개변수에 전달
	3.값에 의한 호출은 메모리에 동일한 값을 복사 후 사용
	4.참조에 의한 호출은 메모리의 주소를 넘기기 때문에 값을 복사하지 않음*/
	public void increase(int[] array) {
		for (int i = 0; i < array.length; i++) {
			array[i]++;
		}
	}
	
	public static void main(String[] args) {
		int[] refArray = {100, 200, 300};
		
		Method10_CallByRef ref = new Method10_CallByRef();
		
		System.out.println("메서드 호출 전");
		for (int i = 0; i < refArray.length; i++) {
			System.out.println("refArray[" + i + "] : " + refArray[i]);
		}
		
		ref.increase(refArray);
		
		System.out.println();
		System.out.println("메서드 호출 후");
		//배열은 참조형이라 메서드 호출 후 값이 변경
		for (int i = 0; i < refArray.length; i++) {
			System.out.println("refArray[" + i + "] : " + refArray[i]);
		}
		
		/*스택(stack)영역 : 함수의 호출과 관계되는 지역 변수와 매개변수가 저장되는 영역,
		스택영역은 함수의 호출과 함께 할당되며, 함수의 호출이 완료 되면 자동으로 소멸합니다
		스택영역은 메모리의 높은 주소에서 낮은 주소의 방향으로 할당됩니다*/
		
		/*힙(heap)영역 : 사용자가 직접 관리 할 수 있는 그리고 해야만 하는 메모리 영역,
		힙영역은 사용자에 의해 메모리 공간이 돌적으로 할당되고 해제 됩니다
		힙영역은 메모리의 낮은 주소에서 높은 주소의 방향으로 할당됩니다*/
		
		//스택영역의 경우 컴파일러가 미리 공간을 예측할 수 있지만 동적변수의 경우 어느 정도 할당 될 지 예측할 수 없기 때문에 런타임(프로그램 실행중)에 결정됩니다
	}

}
