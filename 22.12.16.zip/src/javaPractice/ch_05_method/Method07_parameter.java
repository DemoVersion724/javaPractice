package javaPractice.ch_05_method;

public class Method07_parameter {
	//매개변수를 2개 사용하는 메서드
	public void print(int a, int b) {
		int c = a + b;
		System.out.println("결과값 : " + c);
	}
	//매개변수로 문자열을 받는 메서드 선언
	public void print1(String str) {
		System.out.println(str);
	}
	
	public static void main(String[] args) {
		//변수선언
		int num1 = 11;
		int num2 = 22;
		int result = 0;
		
		//사용할 메서드가 있는 클래스의 인스턴스 선언
		Method07_parameter method = new Method07_parameter();
		
		//메서드 호출
		method.print(10,20);
		//method.print(10,30.0f); //매개변수를 int로 선언 했으므로, 값을 던져줄때에도 같은 데이터 타입으로 호출해야됨
		method.print(num1,num2);
		method.print1("안녕하세요");

	}

}
