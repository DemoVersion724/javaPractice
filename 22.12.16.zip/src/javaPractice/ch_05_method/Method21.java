package javaPractice.ch_05_method;

import java.util.Scanner;

public class Method21 {
	static void putStars(int n, int total) {
		//우하변이 직각인 직각삼각형을 표시하시오
		//별이 출력되는 부분은 putStars() 메서드를 정의해서 구현하세요
		for (int i = 1; i <= total; i++) {
			//공백반복
			if(i <= total - n) {
				System.out.print(" ");
			}
			//별 반복
			else {
				System.out.print("*");
				}
			}
		}

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		System.out.println("좌하변이 직각인 직각삼각형을 표시합니다");
		System.out.print("몇 단 : ");
		int total = input.nextInt();
		
		for (int i = 1; i <= total; i++) {
			putStars(i, total); //메서드 호출
			System.out.println();
		}
		
		input.close();
	}

}
