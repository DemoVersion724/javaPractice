package javaPractice.ch_05_method;

import java.util.Random;
import java.util.Scanner;

public class Method14 {
	//인수(매개변수)가 없는 메서드
	//암산연습
	static Scanner input = new Scanner(System.in); //두 메서드에서 사용하기 위해 클래스 변수로 선언
	
	//지속 여부의 확인
	static boolean confirmRetry() {
		int cont;
		do {
			System.out.print("다시 한번? <Yes-1/No-0> : ");
			cont = input.nextInt();
		} while (cont != 0 && cont != 1);
		return cont == 1; //cont가 1이면 true, 아니면 false
	}
	
	public static void main(String[] args) {
		Random rand = new Random();
		
		System.out.println("암산트레이님!!");
		do {
			//rand.nextInt(n) : 0 (n ~ 1) 까지의 정수를 랜덤으로 반환
			int x = rand.nextInt(900) + 100; //3자릿의 수
			int y = rand.nextInt(900) + 100; //3자릿의 수
			int z = rand.nextInt(900) + 100; //3자릿의 수
		 while (true) {
			System.out.print(x + " + " + y + " + " + z + " = ");
			int k = input.nextInt(); //입력한 값
			
			if(k > x + y + z) { //입력한 답 업다운
				System.out.println("입력한 정수가 높습니다");
			}else if(k < x + y + z) {
				System.out.println("입력한 정수가 낮습니다");
			}else {
				System.out.println("정답입니다");
			}
			
			if(k == x + y +z)  //정답
				break;
				System.out.println("틀렸습니다");
		 	}
		}while (confirmRetry());
		
	}

}







