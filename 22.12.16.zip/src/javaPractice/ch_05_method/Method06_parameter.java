package javaPractice.ch_05_method;

public class Method06_parameter {
	//매개변수가 있는 메서드
	//매개변수는 메서드 호출 시 메모리에 생성되고, 호출 후 복귀 시 소멸
	public void print(int a) {
		System.out.println("결과 값  : " + a);
	}
	
	public static void main(String[] args) {
		int a = 11;
		int b = 22;
		int result = 0;
		
		//사용할 메서드가 있는 클래스의 인스턴스 선언
		Method06_parameter method = new Method06_parameter();
		method.print(10);
		method.print(b);
		method.print(result);
	}

}
