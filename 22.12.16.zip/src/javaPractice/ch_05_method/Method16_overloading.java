package javaPractice.ch_05_method;

public class Method16_overloading {

	public static void main(String[] args) {
		int a, b, c;
		a = 10;
		b = 20;
		c = 30;
		System.out.println(a + ", " + b + ", " + c + " 중 제일 큰수는 " + max(a, b, c) + "입니다");
		System.out.println(a + ", " + b + " 중 제일 큰수는" + max(a, b) + "입니다");
	}
	static int max(int a, int b, int c) { //a, b, c의 최대 값을 반환
		int max = a;
		if(a < b) max = b;
		if(b < c) max = c;
		return max;
	}
	static int max(int a, int b) { //a, b의 최대 값을 반환
		int max = a;
		if(a < b) max = b;
		return max;
	}

}
