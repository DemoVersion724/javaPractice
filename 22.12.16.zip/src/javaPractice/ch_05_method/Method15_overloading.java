package javaPractice.ch_05_method;

public class Method15_overloading {
	//메서드 오버로딩
	//매개변수의 타입 혹은 갯수가 다르면 같은 이름을 가진 메서드를 재정의 할 수 있음
	//C, 파이썬 없음(데이터 타입 명시X), C++, 파이썬에 있는 기본값 기능은 자바에 없음
	public static void main(String[] args) {
		printGreet(); //안녕하세요
		printGreet("안녕~~!"); //안녕~~!
		printGreet("한수","잘 지내셨나요?"); //한수님! 잘 지내셨나요?
		printGreet(3); //안녕하세요. 3번째 보는거에요.
	}
	
	public static void printGreet() {
		System.out.println("printGreet() 메서드가 실행됩니다");
		System.out.println("안녕하세요");
	}
	
	public static void printGreet(String greeting) {
		//같은 이름의 메서드가 있으나 매개변수가 없음
		System.out.println("printGreet(String greeting) 메서드가 실행됩니다");
		System.out.println(greeting);
	}

	public static void printGreet(String name , String greeting) {
		//매개변수가 문자열인 메서드가 있으나 갯수가 다름
		System.out.println("printGreet(String name , String greeting) 메서드가 실행됩니다");
		System.out.println(name + "님! " + greeting);
	}
	
	public static void printGreet(int cnt) {
		//매개변수가 하나인 메서드가 있으나 데이터 타입이 다름
		System.out.println("printGreet(int num) 메서드가 실행됩니다");
		System.out.println("안녕하세요." + cnt + "번째 보는거에요.");
	}
	
	/*<script>
	자바스크립트
	//기본매개변수 : 매개변수에 기본값을 저장, 매개변수가 들어오지 않는 경우에 기본 값으로 대체
	//기본 매개변수와 일반 매개변수를 섞어서 사용할 경우에는 기본 매개 변수가 오른쪽으로 가야됨(인터프린터 언어에서 대부분 사용)
	function earnings (name, wage=8590, hours=40) {
		console.log(`-시급 : ${wage}원`)
		console.log(`-근무시간 : ${hours}시간`)
		console.log(`-급여 : ${wage * hours}원`)
		console.log('')
	}
	//최저 임금으로 최대한 일하는 경우
	earnings('smith');
	
	//시급 1만원으로 최대한 일하는 경우
	earnings('adam', 10000);

	//시급 1만원으로 52시간 일하는 경우
	earnings('tom', 10000, 52);
	</script>*/
	 
}
