package javaPractice.ch_05_method;

import java.util.Scanner;

public class Method13_void {
	//return값이 없는 메서드
	//좌하변이 직각인 직각삼각형을 표시
	static void putStars(int n) { //void 메서드 -> return값이 없는 메서드
		while (n-- > 0) {
			System.out.print('*');
		}
	}

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		System.out.println("좌하변이 직각인 직각 삼각형을 표시합니다");
		System.out.print("몇 단 : ");
		int n = input.nextInt();
		
		for (int i = 0; i <= n; i++) {
			putStars(i);
			System.out.println();
		}
		input.close();
	}

}
