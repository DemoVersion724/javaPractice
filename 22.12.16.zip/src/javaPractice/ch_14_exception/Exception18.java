package javaPractice.ch_14_exception;

import java.util.Scanner;

//로그인 정보가 틀린 경우를 사용자 정의 예외를 만들어서 예외처리 할것

class LoginException extends Exception{
	public LoginException(String message) {
		super(message);
	}
	//예외가 발생할 시에 로그로 남기는 코드 : 해킹시도(매크로) 접근 모니터링 목적, 사용자 로그인 예외접근 모니터링 목적
	//파일 혹은 데이터베이스에 저장
	public LoginException(String message, String memberID, String password) {
		super(message);
		updateLog(memberID, password);
	}
	public void updateLog(String memberID, String password) {
		
	}
}

public class Exception18 {
	String memberID = "abc";
	String password = "1234";
	Scanner input = new Scanner(System.in);
	
	private boolean confirmLogin(String memberID, String password) throws LoginException {
		if(this.memberID.equals(memberID) && this.password.equals(password)) {
			System.out.println("로그인 되었습니다");
			return true;
		}
		else {
			throw new LoginException("로그인 정보가 정확하지 않습니다");
			//return false;
		}
	}

	public void login() {
		String memberID, password;
		boolean answer;
		System.out.println("로그인 정보를 입력 해주세요");
		do {
				System.out.print("아이디를 입력해주세요 >> ");
				memberID = input.nextLine();
				System.out.print("비밀번호를 입력해주세요 >> ");
				password = input.nextLine();
				try {	
					answer = confirmLogin(memberID, password);
				} catch (LoginException e) {
					System.out.println(e.getMessage());
					answer = false;
				}
			}
			while(!answer);
	}
	
	public static void main(String[] args) {
		
		Exception18 ex = new Exception18();
		ex.login();
		
	}

}
