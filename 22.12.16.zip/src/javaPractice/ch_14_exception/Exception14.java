package javaPractice.ch_14_exception;

import java.util.Scanner;

public class Exception14 {
	private static final Scanner in = new Scanner(System.in);
	
	public static void input() {
		int age = 0;
		
		try {
			System.out.print("나이 = ");
			age = Integer.parseInt(in.nextLine());
		} catch (NumberFormatException ex) {
			System.out.println("오류 발생 = " + ex.getMessage());
			return;
		}
		finally {
			System.out.println("나이 = " + age + "세");
		}
	}
	
	public static void main(String[] args) {
		System.out.println("Main method Start!!!");
		input();
		System.out.println("Main Method End!!!");
	}

}
