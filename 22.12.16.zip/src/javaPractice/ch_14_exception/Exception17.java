package javaPractice.ch_14_exception;

class IDFormatException extends Exception{
	public IDFormatException(String message) {
		super(message);
	}
}

public class Exception17 {
	
	private String userID;
	
	public String getUserID() {
		return userID;
	}
	
	public void setUserID(String UserID) throws IDFormatException{
		if(userID == null) {
			throw new IDFormatException("아이디는 null 알 수 없습니다.");
		}
		else if(userID.length() < 8 || userID.length() > 20) {
			throw new IDFormatException("아이디는 8자 이상 20자 이하로 쓰세요");
		}
		
		this.userID = userID;
	}
	
	public static void main(String[] args) {

		Exception17 test = new Exception17();
		String userID = null;
		try {
			test.setUserID(userID);
		} catch (IDFormatException e) {
			System.out.println(e.getMessage());
		}
		
		userID = "1234567";
		try {
			test.setUserID(userID);
		} catch (IDFormatException e) {
			System.out.println(e.getMessage());
		}

	}

}
