package javaPractice.ch_14_exception;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class Exception06 {

	public static void main(String[] args) {
		String path = ".\\sample_file\\test2.txt";
		try {
			FileInputStream fis = new FileInputStream(path);
			System.out.println("파일 열기 성공");
		}
		
		/*문법 상 Exception가 위쪽에 존재한다면 상위요소의 Exception에서 예외 catch가 가능하기 때문에
		 하위요소인 FileNotFoundException, IOException 까지 미치지 않기에 에러 발생*/
		
		catch(FileNotFoundException e){ //파일이 존재하지않다는 예외 처리
			//다형성을 이용한 예외 처리
			System.out.println("*** FileNotFoundException ***");
			//e.printStackTrace();
		}
		catch(IOException e) {
			System.out.println("*** IOException ***");
			e.printStackTrace();
		}
		catch (Exception e) { //모든 예외 처리
			System.out.println("*** Exception ***");
			e.printStackTrace();
		}
		finally {
			System.out.println("프로그램 종료");
		}
	}

}
