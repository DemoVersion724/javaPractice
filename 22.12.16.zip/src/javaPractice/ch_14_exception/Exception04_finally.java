package javaPractice.ch_14_exception;

public class Exception04_finally {

	public static void main(String[] args) {
	//try/cahch문에 선택적으로 finally라는 구문을 추가 : try구문 내부에서 오류가 발생 하든 하지않던 간에 상관없이 무조건 실행되는 구문
		int a = 0;
		int b =2;
		try {
			System.out.println("외부로 연결");
			int c = b / a;
			System.out.println("연결 해제");
		}
		catch(ArithmeticException e) {
			System.out.println("오류가 발생했습니다");
		}
		finally {
			System.out.println("연결 해제");
		}
		System.out.println("여기도 수행됩니다");
	}

}
