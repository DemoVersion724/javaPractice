package javaPractice.ch_14_exception;

import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.*;

public class Exception13_Date {

	public static void main(String[] args) {
		PrintStream ps = null; //파일 error.log에 출력할 준비
		FileOutputStream fos = null; //파일 저장을 위해
		try {
			fos = new FileOutputStream(".\\output_file\\error.log", true); //true : 내용이 누적업데이트 됨
			ps = new PrintStream(fos); //err의 출력을 화면에 아닌, error.log파일로 변경한다
			System.setErr(ps);
			
			System.out.println(1);
			System.out.println(2);
			System.out.println(3);
			System.out.println(0/0); //예외발생
			System.out.println(4); //실행되지 않는다
			
		} catch (Exception ae) {
			//예외 발생 시간 출력
			System.err.println("----------------------------------");
			System.err.println("예외발생시간 : " + new Date()); //현재시간 출력
			ae.printStackTrace(System.err);
			System.err.println("예외 메시지 : " + ae.getMessage());
			System.err.println("----------------------------------");
		}//try-catch의 끝
		System.out.println(6);
	}

}
