package javaPractice.ch_14_exception;

import java.io.FileOutputStream;
import java.io.PrintStream;

public class Exception12_outputFile {

	public static void main(String[] args) {
		PrintStream ps = null; //파일 error.log에 출력할 준비
		FileOutputStream fos = null; //파일 저장을 위해 //데이터를 파일에 바이트 스트림으로 저장하기 위해 사용한다.
		//FileInputStream : 파일의 내용을 읽음
		//FileOutputStream : 파일의 내용을 작성함
		
		try {
			fos = new FileOutputStream(".\\output_file\\error.log", true); //true : 내용이 누적업데이트 됨
			ps = new PrintStream(fos); //err의 출력을 화면에 아닌, error.log파일로 변경한다
			
			System.out.println(1);
			System.out.println(2);
			System.out.println(3);
			System.out.println(0/0); //예외발생
			System.out.println(4); //실행되지 않는다
			
		} catch (Exception ae) {
			ae.printStackTrace(ps); //Exception이 발생한 이유와 어디에서 발생했는지 전체적인 단계를 출력
			ps.println("예외 메시지 : " + ae.getMessage()); //화면대신 error.log파일에 출력한다
		}//try-catch의 끝
		System.out.println(6);
	}

}
