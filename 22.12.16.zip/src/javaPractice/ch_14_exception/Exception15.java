package javaPractice.ch_14_exception;
//사용자 정의 예외처리
class AgeException extends Exception{ //사용자 정의 예외클래스 (반드시 Exception를 상속 받아야함)
	public AgeException() {}
	public AgeException(String message) {
		super(message);
	}
	public void printStackTrace() {
		System.out.println(getMessage());
		super.printStackTrace();
	}
}

public class Exception15 {
	public static void ticketing(int age) throws AgeException{
		if(age < 0) {
			throw new AgeException("나이 입력이 잘못되었습니다.");
		}
	}

	public static void main(String[] args) {
		int age = -19;
		try {
			ticketing(age);
		} catch (AgeException e) {
			e.printStackTrace();
		}
	}

}
