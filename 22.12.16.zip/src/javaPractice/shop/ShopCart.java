package javaPractice.shop;

public class ShopCart {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
