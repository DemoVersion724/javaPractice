package javaPractice.shop;

public class Product { //상품 관련 클래스. 장바구니 사용전에 상품을 보여줌
	private final int productID; //상품 코드
	private final String productName; //상품 이름
	private final int proice; //가격
	
	Product(int productID, String productName, int proice){ //생성자를 통해 입력
		this.productID = productID;
		this.productName = productName;
		this.proice = proice;
	}

	public int getProductID() {
		return productID;
	}

	public String getProductName() {
		return productName;
	}

	public int getProice() {
		return proice;
	}

}
