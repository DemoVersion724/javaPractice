package javaPractice.shop;

import java.util.Scanner;

public class MemberInsert{ 
	
	Scanner input = new Scanner(System.in); //콘솔 입력 사용
	Member member;

	public MemberInsert(String memberID, String password, String name) {
		member = new Member(memberID, password, name);
	}
	
	void updateAddInfo() {
		//추가정보 입력 yes or no
		System.out.println("추가 정보를 입력하시겠습니까?");
		System.out.print("추가 정보를 입력하시려면 Y, 그만 하실려면 N을 입력해 주십시요 >> ");
		String info = input.nextLine();
		if(info.equals("Y") || info.equals("y")) {
			System.out.print("주소 : ");
			String address = input.nextLine();
			System.out.print("이메일 : ");
			String email = input.nextLine();
		}
	}	
	
	//로그인 메서드
	public void login() {
		String memberID, password;
		System.out.println("로그인 정보를 입력해 주세요.");
		do {
			System.out.print("아이디를 입력해 주세요 >> ");
			String loginId = input.nextLine();
			System.out.print("비밀번호를 입력해 주세요 >> ");
			String loginPw = input.nextLine();
		}
		while(!confirmLogin(memberID, password));
	}
	
	private boolean confirmLogin(String memberId, String password) {
		if(member.getMemberId().equals(memberId) && member.getPassword().equals(password)) {
			return true;
	} else{
			System.out.println("로그인 정보가 정확하지 않습니다");
			return false;
		
} //end MemberInsert

