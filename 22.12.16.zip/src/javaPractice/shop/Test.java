package javaPractice.shop;
/*1. 회원 가입, 로그인, 장바구니 관련 기능을 구현하세요.
 * 
2. 프로그램은 7개의 클래스로 구성됩니다.
1) Test : main 메서드가 있어서 기능 테스트를 할 수 있는 클래스
2) Member : 회원 관련 모델이 정의된 클래스
3) MemberInsert : 회원 가입 및 로그인 기능이 정의된 클래스
4) Product : 상품 관련 모델이 정의된 클래스
5) ShopProduct : 생성자로 상품을 저장하고 전시하는 기능이 정의된 클래스
6) Cart : 장바구니 관련 모델이 정의된 클래스
7) ShopCart : 장바구니에 상품을 저장하고 출력하는 기능이 정의된 클래스

3. 위의 클래스 중 Test, Member, Product, Cart 는 제공이 됩니다. 
MemberInsert, ShopProduct, ShopCart를 완성하십시요.

4. MemberInsert 클래스에는 1) 추가정보를 입력할지 물어서 "Y"를 입력 받으면 추가입력을 받고
"N"을 누르면 추가 입력을 받지 않는 기능이 있어야 합니다.
2) 로그인 기능은 회원 가입을 한 정보를 기준으로 처리하고, 로그인 정보가 정확하지 않으면 계속 로그인 정보를 물어야 합니다.

5. ShopProduct 클래스는 생성자에서 상품을 저장하고, 장바구니에 상품을 담기전에 어떤 상품이 있는지 보여주는 기능만 들어가면 됩니다.
상품은 실행 예에 나오는 상품 3개만 입력하십시요.

6. ShopCart 클래스는 고객이 선택한 상품코드를 기준으로 상품을 저장하고, 추가로 상품을 선택 받을지 입력을 받아
"Y"를 입력하면 추가로 장바구니에 상품을 담고, "N"을 입력하면 지금까지 선택한 상품의 상품코드와 갯수를 출력합니다.
(상품 이름과 가격은 출력하지 않습니다.)
장바구니에 저장 가능한 최대 개수는 10개입니다.*/

import java.util.Scanner;

public class Test {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in); //콘솔 입력 사용
		ShopProduct sp = new ShopProduct(); //상품 관련
		ShopCart sc = new ShopCart(); 
		
		//회원가입 기본정보
		System.out.println("01.회원가입 시작");
		System.out.println("회원가입 정보를 입력하세요");
		
		System.out.print("아이디 : ");
		String memberID = input.nextLine();
		System.out.print("비밀번호 : ");
		String password = input.nextLine();
		System.out.print("이름 : ");
		String name = input.nextLine();
		
		//회원 가입 관련 클래스의 생성자에게 아이디, 비밀번호, 이름전달
		MemberInsert m = new MemberInsert(memberID, password, name);
		m.updateAddInfo(); //추가정보 입력
		m.printMemberInfo(); //회원가입 정보 출력
		System.out.println("회원가입해주셔서 감사합니다");
		System.out.println("01.회원 가입 종료");
		System.out.println("");
		
		System.out.println("02.로그인 시작");
		m.login(); //로그인 처리
		System.out.println("로그인 종료");
		System.out.println("");
		
		System.out.println("03.장바구니 시작");
		System.out.println("상점에서 구매 가능한 상품입니다.");
		sp.printProduct(); //상품진열
		sc.selectProduct(); //상품을 선택
		System.out.println("장바구니에 담은 상품은 아래와 같습니다");
		sc.printCart(); //장바구니에 담은 상품 출력
		System.out.println("03.장바구니 종료");
		System.out.println("");
		
	}

}
