package javaPractice.shop;

public class ShopProduct extends Product{
	ShopProduct(int productID, String productName, int proice) {
		super(productID, productName, proice);
	}
	
	Product[] product = new Product[3];
	
	public void genProduct() {
		Product product1 = new Product(1, "블랜딩 커피", 5000);
		product[0] = product1;
		Product product2 = new Product(2, "파나마 게이샤", 15000);
		product[1] = product2;
		Product product3 = new Product(3, "이디오피아 커피", 10000);
		product[2] = product3;
	};
}
