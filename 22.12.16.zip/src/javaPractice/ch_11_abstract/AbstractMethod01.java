package javaPractice.ch_11_abstract;

public class AbstractMethod01 {

	public static void main(String[] args) {
		//선언부만 정의하고 구체적인 내용은 비워 놓은 메서드 구체적인 내용을 적지 않았기 때문에 이를 상속받은 하위 클래스에서는 사용하려면 반드시 구현하여야 사용 가능합니다
		//자식 클래스에서 반드시 오버라이딩해야만 사용할 수 있는 메소드
	}

}
