package javaPractice.ch_11_abstract;

public class AbstractClass {

	public static void main(String[] args) {
		//추상메서드를 멤버로 가지는 클래스입니다 추상클래스는 일반적인 메서드도 가질수 있지만 추상메서드를 하나라도 포함하는 클래스
	}

}
