package javaPractice.ch_13_innerClass;

class A{ //외부클래스
	
	class InstanceInner{} //내부 클래스
	/*내부 클래스의 장점
	 	1. 내부 클래스에서 외부 클래스의 멤버에 손쉽게 접근할 수 있게 됩니다.
		2. 서로 관련 있는 클래스를 논리적으로 묶어서 표현함으로써, 코드의 캡슐화를 증가시킵니다.
		3. 외부에서는 내부 클래스에 접근할 수 없으므로, 코드의 복잡성을 줄일 수 있습니다.*/
	
	static class StaticInner{} //static 내부 클래스. 스태틱 멤버간의 접근 가능
	
	StaticInner st1 = new StaticInner();
	
	//인스턴스 멤버간의 접근 가능
	InstanceInner ii1 = new InstanceInner();
	
	static void StaticMethod() {
		//스태틱 멤버가 스태틱 내부 클래스에 접근가능
		StaticInner st2 = new StaticInner();
		
		//스태틱 멤버는 인스턴스 멤버에 접근 불가
		//InstanceInner ii2 = new InstanceInner(); //에러발생
	}
	
	void instanceMethod() {
		//인스턴스 멤버는 모두 접근 가능
		StaticInner st3 = new StaticInner();
		InstanceInner ii3 = new InstanceInner();
	}
}

public class Ex01 {

	public static void main(String[] args) {

	}

}
