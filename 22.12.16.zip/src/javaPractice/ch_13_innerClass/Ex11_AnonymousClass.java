package javaPractice.ch_13_innerClass;

/*익명객체의 로컬 변수 사용
메소드의 매개변수나 로컬 변수를 익명 객체 내부에서 사용할 때도 제한이 없음
메소드가 종료 되어도 익명 객체가 실행 상태로 존재할 수 없음
문제는 메소드의 매개 변수나 지역 변수를 익명 객체 내부에서 사용할 때인데
메소드가 실행이 끝나면 스택 메모리에서 사라지기 떄문에 익명 객체에서 지속적으로 사용을 할 수 없음*/

interface Calculatable{
	public int sum();
}
class Anoymous{
	private int field;
	
	public void method(final int arg1, int arg2) {
		final int var1 = 0;
		int var2 = 0;
		
		field = 10; //외부클래스의 멤버 변수
		
		//arg1 = 20; //매개변수가 상수라서 수정 불가
		//arg2 = 20; //매개변수가 익명객체에서 사용해서 상수화되어 에러, 변수선언을 상수선언으로 처리
		
		//var1 = 20; //지역변수가 상수라서 수정 불가
		//var2 = 20; //지역변수가 익명객체에서 사용해서 상수화되어 에러

		Calculatable calc = new Calculatable() {
			@Override
			public int sum() {
				int result = field + arg1 + arg2 + var1 + var2;
				return result;
			}
		};
		System.out.println(calc.sum());
	}
}

public class Ex11_AnonymousClass {

	public static void main(String[] args) {
		Anoymous anoy = new Anoymous();
		anoy.method(0, 0); //10
	}

}
