package javaPractice.ch_12_interface.Calc02;

public class Test {
	public static void main(String[] args) {
		int num1 = 10;
		int num2 = 5;
		
		CompleteCalc calc = new CompleteCalc();
		System.out.println(calc.add(num1, num2));
		System.out.println(calc.substact(num1, num2));
		System.out.println(calc.times(num1, num2));
		System.out.println(calc.divide(num1, num2));
		calc.showInfo();
		calc.description();
		
		int[] arr = {1, 2, 3, 4, 5};
		System.out.println(Calc.total(arr));
	}
}

/*//자바스크립트 황금규칙(위의 예제와 상관없음)
1.var 대신 let이나 const로 변수를 선언한다
2.엄격모드 strict mode를 사용한다
3.형식을 확인하고 자동 형변환 automatix type conversion을 피한다
4.프로토 타입을 이용하더라도 최신 클래스와 생성자, 메서드 문법을 이용한다
5.생성자나 메서드 밖에서는 this를 사용하지않는다*/