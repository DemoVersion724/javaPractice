package javaPractice.ch_12_interface.customer;

interface Buy2{
	void buy();
	
	default void order() {
		System.out.println("구매 주문");
	}
}

interface Sell2{
	void sell();
	
	default void order() {
		System.out.println("판매 주문");
	}
}

class Customer2 implements Buy2,Sell2{
	@Override
	public void buy() {
		System.out.println("구매하기");
	}
	
	@Override
	public void sell() {
		System.out.println("판매하기");
	}
	
	//디폴트 메서드가 중복이 되었으나 두 인터페이스를 구현하는 Customer 클래스에서 재정의 해야함
	@Override
	public void order() {
		System.out.println("고객 판매 주문");
	}
}

/*두 인터페이스의 디폴트 메서드가 중복되는 경우
한 클래스가 다중 구현한 인터페이스에 동일한 디폴트 메서드가 있는 경우
오버라이딩을 해야함*/

public class Test02 {

	public static void main(String[] args) {
		Customer2 customer = new Customer2();
		
		Buy2 buyer = customer;
		buyer.buy();
		buyer.order(); //고객 판매 주문
		
		Sell2 seller = customer;
		seller.sell();
		buyer.order(); //고객 판매 주문
		
		if(seller instanceof Customer2) {
			//seller를 하위 클래스 형인 Custmer로 다시 형변환
			Customer2 customer2 = (Customer2) seller;
			customer2.buy();
			customer2.sell();
		}
		customer.order(); //고객 판매 주문
	}
	
}
