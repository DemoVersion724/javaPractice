package javaPractice.ch_20_java_util_package;

import java.text.SimpleDateFormat;
import java.util.Date;

/*Date와 simpleDateFormat 클래스를 이용해서
오늘의 날짜를 아래와 같이 출력하는 프로그램을 작성하시오*/

//실행결과 : 2022년 08월 22일 월요일 18시 09분

public class Exam08 {

	public static void main(String[] args) {
		Date day = new Date();
		
		String today = "yyyy년 MM월 dd일 E요일 ";
		String time = "HH시 mm분 ss초";
		
		SimpleDateFormat p1 = new SimpleDateFormat(today);
		SimpleDateFormat p2 = new SimpleDateFormat(time);
		System.out.print(p1.format(day) + p2.format(day));
		System.out.println();
		
		//한줄 출력
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy년 MM월 dd일 E요일 HH시 mm분 ss초");
		System.out.println(sdf.format(new Date()));
		
	}

}
