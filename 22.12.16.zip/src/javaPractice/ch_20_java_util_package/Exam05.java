package javaPractice.ch_20_java_util_package;
/*
Calendar 클래스는 달력을 표현 한 클래스 입니다
Calendar 클래스를 사용해서 현재 시간이 나오도록 구현 하세요
https://docs.oracle.com/javase/7/docs/api/java/util/Calendar.html
yyyy년 mm월 dd일
n요일 오전 / 오후
nn시 nn분 nn초
*/

/*실행 결과
2022년 12월 16일 
토요일 
오전 11시 28분 24초 */

import java.util.Calendar;

public class Exam05 {
	
	public static String getDayToStr(int day) {
		String[] days = {"일","월","화","수","목","금","토"};
		return days[day - 1];
	}
	
	public static void main(String[] args) {
		Calendar now = Calendar.getInstance();
		int year = 0; //년
		int month = 0; //월
		int day = 0; //일
		String strWeek = null; //요일
		String strAmPm = null; //오전/오후
		int hour = 0; //시
		int minute = 0; //분
		int second = 0; //초
		
		//년, 월, 일
		year = now.get(Calendar.YEAR);
		month = now.get(Calendar.MONTH) + 1; 
		day = now.get(Calendar.DATE);
		
		//요일
		strWeek = getDayToStr(Calendar.DAY_OF_WEEK);
		
		//오전, 오후
		int amPm = now.get(Calendar.AM_PM);
		if(amPm == Calendar.AM) {
			strAmPm = "오전";
		} else {
			strAmPm = "오후";
		}
		
		//시, 분, 초
		hour = now.get(Calendar.HOUR);
		minute = now.get(Calendar.MINUTE);
		second = now.get(Calendar.SECOND);
		
		System.out.print(year + "년 ");
		System.out.print(month + "월 ");
		System.out.println(day + "일 ");
		System.out.println(strWeek + "요일 ");
		System.out.print(strAmPm + " ");
		System.out.print(hour + "시 ");
		System.out.print(minute + "분 ");
		System.out.println(second + "초");
		
	}

}
