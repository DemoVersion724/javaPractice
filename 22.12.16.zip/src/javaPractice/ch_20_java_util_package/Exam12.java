package javaPractice.ch_20_java_util_package;

import java.time.LocalDate;

public class Exam12 {

	public static void main(String[] args) {
		/*클래스들의 정보 값 변경하기 
		각 클래스에는 필드 값들을 특정 값 으로 변경하수 있는 메서드가 있음
		withYear(int) 년 변경, withMonth(int) 월 변경,
		withDayOfYear(int) 년의 일 변경, withDayOfMonth(int) 월의 일 변경*/
		
		LocalDate id = LocalDate.now();
		System.out.println(id); //2022-12-16
		
		LocalDate new_id1 = id.withYear(1999).withMonth(8);
		LocalDate new_id2 = id.withYear(1999).withDayOfYear(33);
		LocalDate new_id3 = new_id1.withDayOfYear(33);
		
		//년을 1999로, 일을 8으로 변경.
		System.out.println(new_id1); //1999-08-16
		
		//년을 1999로, 년의 33일로 변경.
		System.out.println(new_id2); //1999-02-02
		
		System.out.println(new_id3); //1999-02-02
	}

}
