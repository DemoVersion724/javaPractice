package javaPractice.ch_04_control;

import java.util.Scanner;

public class Exam39_array {

	public static void main(String[] args) {
		//키보드로 부터 학생수와 각 학생들의 점수를 입력 받아서, 최고 점수 및 평균을 구하는 프로그램
		boolean run = true; //반복문의 조건으로 사용 -> 값이 false가 된다면 반복문이 종료
		int stydentNum = 0; //학생수
		int[] scores = null; //점수를 입력받을 빈배열 생성, 사용자에게 입력받은 학생수를 기준으로 배열 생성
		Scanner input = new Scanner(System.in);
		while (run) {
			System.out.println("---------------------------------------------");
			System.out.println("1.학생수 | 2.점수입력 | 3.점수리스트 | 4.분석 | 5.종료");
			System.out.println("---------------------------------------------");
			System.out.print("선택> ");
			int selectNo = Integer.parseInt(input.nextLine());
			if (selectNo == 1) {
				//학생수를 입력받아서 배열생성
				System.out.print("학생수 입력> ");
				stydentNum = Integer.parseInt(input.nextLine()); 
				scores = new int[stydentNum];
			}
			else if(selectNo == 2) {
				//생성된 배열의 갯수 만큼 점수입력
				for (int i = 0; i < scores.length; i++) {
					System.out.print("scores [" + i + "] : ");
					scores[i] = Integer.parseInt(input.nextLine()); 
				}
			}
			else if(selectNo == 3) {
				//입력받은 배열의 값을 출력
				for (int i = 0; i < scores.length; i++) {
					System.out.println("scores [" + i + "] : " + scores[i]);
				}
			}
			else if(selectNo == 4) {
				//최고점수, 평균점수 출력
				int max = 0;
				int sum = 0;
				double avg = 0;
				for (int i = 0; i < scores.length; i++) {
					max = (max < scores[i]) ? scores[i] : max;
					sum += scores[i];
				}
				avg = (double) sum / stydentNum;
				System.out.println("최고점수 : " + max);
				System.out.println("평균점수 : " + avg);
			}
			else if(selectNo == 5) {
				//run 값 변경
				run = false;
			}
		}
		input.close();
		
		
	}

}
