package javaPractice.ch_04_control;

import java.util.Scanner;

public class Exam23_break {

	public static void main(String[] args) {
		//반복문을 빠져나오는 방법은 1)조건식이 false가 되거나 2)break문이 시행 break문은 반복을 멈추게함
		//반복문이 진행되다가 break문을 만나면 곧 바로 반복문을 벗어나서 반복문 다음의 코드를 수행
		//break문은 특정 조건을 만족하면 반복문을 벗어날 때 사용하면 유용
		Scanner input = new Scanner(System.in);
		int sum = 0;
		int num;
		
		while (true) {
			System.out.print("더할숫자를 입력하시오(종료하려면 0) : ");
			num = input.nextInt();
			if(num == 0) { //만약 0을 입력하였다면 종료
				break;
			}
			sum += num; //입력받은 값 더해주기
		}
		System.out.println("현재까지의 총합 = " + sum);
		input.close();
	}

}
