package javaPractice.ch_04_control;

public class Exam33_array {

	public static void main(String[] args) {
		//2차원배열 선언 및 출력
		int[][] arr = new int[2][3];
		//2차원 배열에 접근 할때는 중첩 for문이용
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr[i].length; j++) {
				System.out.print(arr[i][j] + " ");
			}
			System.out.println();
		}
		System.out.println("행 : " + arr.length);
		System.out.println("열 : " + arr[0].length);
	}

}
