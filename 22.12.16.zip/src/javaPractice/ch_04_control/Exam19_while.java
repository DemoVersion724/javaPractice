package javaPractice.ch_04_control;

import java.util.Scanner;

public class Exam19_while {

	public static void main(String[] args) {
		try (Scanner input = new Scanner(System.in)) {
			String answer = "Y"; //while이 시작 될 수 있도록 응답 값을 초기화
			int count = 0;
			
			//while문
//		while (answer.equals("Y") && count < 5 ) {
//			System.out.println("음악을 재생하시겠습니까?(Y)");
//			answer = input.nextLine(); //사용자의 응답을 받습니다
//			if (answer.equals("Y")) {
//				++count;
//				System.out.println("음악을" + count + "재생했습니다");
//			}
//		}
//		System.out.println("재생종료");
			
			//for문
			for (; answer.equals("Y") || answer.equals("y");) {
				System.out.println("음악을 재생하시겠습니까?(Y)");
				answer = input.nextLine();
				if (answer.equals("Y") || answer.equals("y")) {
					++count;
					System.out.println("음악을" + count + "재생했습니다");
				}
			}
			System.out.println("재생종료");
			input.close();
		}
	}

}
