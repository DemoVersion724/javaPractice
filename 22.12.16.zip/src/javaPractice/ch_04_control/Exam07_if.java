package javaPractice.ch_04_control;

import java.util.Scanner;

public class Exam07_if {

	public static void main(String[] args) {
		//문제1
		//사용자에게 입력받은 정수가 양수인지, 0인지, 음수인지 알려주는 코드를 완성하세요
		Scanner input = new Scanner(System.in);
		int n;
		System.out.print("숫자를 입력하세요>>");
		n = input.nextInt();
		
		if (n > 0) {
			System.out.println("입력받은숫자는 양수 입니다");
		}
		else if(n == 0){
			System.out.println("입력받은숫자는 0 입니다");
		}
		else {
			System.out.println("입력받은 숫자는 음수 입니다");
		}
		
		//문제2
		//사용자에게 성적을 입력받아 if문을 사용해서 학점을 출력하는 코드를 완성하세요 단,입력은 0 ~ 100까지 입력이 됩니다
		//기준 : A : 90 ~ 100, B : 80 ~ 89, C : 70 ~ 79, D : 60 ~ 69, F : 0 ~ 59
		int num;
		System.out.print("성적을 입력하세요>>");
		num = input.nextInt();
		//입력은 0 ~ 100까지 입력된다는 가정은 준 이유 : 조건은 프로트단에서 자바스크립트로 설정하기 때문
		if(num <= 100 && num >= 0) {
			if(num >= 90) {
				System.out.println("A");
			}
			else if(num >= 80) {
				System.out.println("B");
			}
			else if(num >= 70) {
				System.out.println("C");
			}
			else if(num >= 60) {
				System.out.println("D");
			}
			else {
				System.out.println("F");
			}
		}
		else {
			System.out.println("성적을 다시확인바랍니다");
		}
		input.close();
	}

}
