package javaPractice.ch_04_control;

public class Exam40_array {

	public static void main(String[] args) {
		//아래의 배열을 이용해서 랜덤으로 조편성을 하세요 한 조의 인원은 3명입니다
		String[] students = {"김대환","김정원","김준혁","김지혜","김혜현","박기훈","박성민","박소희","박정혜","박준휘","배 규","손하늘",
							 "신용화","오범수","오원택","오해준","유수현","육승민","이기행","이성호","이승재","이영주","장명규","장윤영",
							 "주민석","최현지","황희윤"};
		int range = 3; //한 조의 인원
		int count = 0;
		
		for (int i = 0; i < 10000; i++) {
			int random = (int)(Math.random() * students.length); //배열의 범위 (0 ~ 26)
			String temp = students[0];
			students[0] = students[random];
			students[random] = temp;
		}
		for (int i = 0; i < students.length; i++) {
			if((i + 1) % range == 1) {
				System.out.print( ++ count + "조 : ");
			}
			System.out.print(students[i] + " ");
			if((i + 1) % range == 0) {
				System.out.println();
			}
		}
		
		
	}

}
