package javaPractice.ch_04_control;

public class Exam15_for {

	public static void main(String[] args) {
		//중첩 for문으로 구구단 출력
		//for문은 또 다른 for문을 내포할 수 있는데, 이것을 중첩 for문이라고 함 
		//이 경우 바깥쪽 for문이 한 번 실행할 때마다 중천된 for문은 지정된 횟수만큼 반복해서 돌다가 다시 바깥쪽 for문이 돌아감
		
		for (int i = 2; i <= 9; i++) { //바깥 쪽 for문 8번반복 
			System.out.println(i + "단");
			for (int j = 1; j <= 9; j++) { //중첩 for문 9번반복 
				System.out.println(i + "X" + j + "=" + i * j);
			}
			System.out.println();
		}

	}

}
