package javaPractice.ch_04_control;

import java.util.Scanner;

public class Exam21_while {

	public static void main(String[] args) {
		//문제1
		//음수가 입력 될 때 까지, 사용자가 입력한 정수의 합계룰 계산하여 출력하는 프로그램을 작성하시오
		//while문을 사용, break 사용하지말것
		Scanner input = new Scanner(System.in);
		
		int sum = 0;
		int n = 0; //while문이 조건이 1)처음에 참이 되어야하고 2)합에 영향을 미치지 않아야함
		
		while (n >= 0) {
			sum += n;
			System.out.print("정수를 입력하세요>>");
			n = input.nextInt();
		}
		System.out.println("정수의 합계 : " + sum);
		input.close();
	}

}
