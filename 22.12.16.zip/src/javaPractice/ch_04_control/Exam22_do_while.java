package javaPractice.ch_04_control;

import java.util.Scanner;

public class Exam22_do_while {

	public static void main(String[] args) {
		//do_while 권장하지 않음
		int num = 100;
		do {
			System.out.println("적어도 한번은 출력되는 문장");
		} while (num < 10);
		
		//문제1
		//do while문을 사용하여 사용자로 부터 월의 번호를 입력받는 프로그램을 작성해 보세요
		//사용자가 올바른 월 번호를 입력할 때 까지 반복을 계속합니다 
		//사용자가 올바른 월 번호를 입력해야만 다음 문장으로 넘어갑니다
		Scanner input = new Scanner(System.in);
		int month;
		
		do {
			System.out.print("올바른 월을 입력하시오[1-12]");
			month = input.nextInt();
		} while (month < 1 || month > 12 );
		System.out.println("사용자가 입력한 월은 " + month + "월 입니다");
		
		//문제2
		//음수가 입력 될 때 까지, 사용자가 입력한 정수의 합계룰 계산하여 출력하는 프로그램을 작성하시오
		//do while문을 사용, break 사용하지말것
		int sum = 0;
		int n; 
		do {
			System.out.print("정수를 입력하세요>>");
			n = input.nextInt();
			if(n >= 0) {
				sum += n;
			}
		} while (n >= 0); 
		System.out.println("정수의 합계 : " + sum);
		input.close();
	}

}
