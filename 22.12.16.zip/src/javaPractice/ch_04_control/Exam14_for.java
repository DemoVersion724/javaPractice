package javaPractice.ch_04_control;

public class Exam14_for {

	public static void main(String[] args) {
		int i = 0;
		//초기화, 조건식, 증감식 모두 생략가능 : 모두생략하게 되면 무한루프 주의
		for (;i < 10;) {
			System.out.println("i = " + i);
			i++;
		}

	}

}
