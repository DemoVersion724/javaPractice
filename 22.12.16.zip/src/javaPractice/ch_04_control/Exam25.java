package javaPractice.ch_04_control;

import java.util.Scanner;

public class Exam25 {

	public static void main(String[] args) {
		//문제1
		//while, break를 사용하여 사용자가 입력한 점수들의 평균을 내는 프로그램을 작성합니다
		//만약 사용자가 음수를 입력하면 break에 의하여 반복 루프가 종료되게 합니다
		Scanner input = new Scanner(System.in);
		int num;
		int sum = 0;
		int age = 0;
		
		while(true) {
			System.out.print("점수를 입력하세요>>");
			num =input.nextInt();
			if(num < 0) {
				break;
			}
			sum += num;		
			age++;
		}
		System.out.println("총점은 : " + sum);
		System.out.println("평균은 : " + sum / (double)age);
		input.close();
	}

}
