package javaPractice.ch_04_control;

import java.util.Scanner;

public class Exam27_array {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int[] abcd = new int[4];
		int sum;
		
		for (int i = 0; i < abcd.length; i++) {
			System.out.print((i+1) + "번째 숫자를 입력하세요>> ");
			abcd[i] = input.nextInt();
		}
		
		sum = abcd[0] + abcd[1] + abcd[2] + abcd[3];
		
		System.out.println("합계 : " + sum);
		input.close();
	}

}
