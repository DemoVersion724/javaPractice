package javaPractice.ch_04_control;

import java.util.Arrays;

public class Exam32_array {

	public static void main(String[] args) {
		//로또번호 구하기 1)1 ~ 45 까지의 임의의 수 구하기 2)중복의 체크
		int range = 6;
		int[] number = new int[range];
		
		//방법1
		while (range > 0) {
			int temp = (int)(Math.random() * 45) + 1; //1 ~ 45의 임의의 값을 얻는다
			
			//중복확인
			boolean result = true; //중복확인 값을 저장하기 위한 변수, 중복이면 false
			
			if(result) {
				number[range - 1] = temp;
				range--;
			}
		}
		System.out.println(Arrays.toString(number));
		
		//방법2
		while (range > 0) {
			int temp = (int)(Math.random() * 45) + 1; //1 ~ 45의 임의의 값을 얻는다
		
			boolean result = true; //중복확인 값을 저장하기 위한 변수, 중복이면 false
			for(int n : number) {
				if(n == temp) {
					System.out.println(temp + "은 중복된 값입니다");
					result = false;
				}
			}
			if(result) {
				number[range - 1] = temp;
				range--;
			}
		}
		System.out.println(Arrays.toString(number));
		
	}

}
