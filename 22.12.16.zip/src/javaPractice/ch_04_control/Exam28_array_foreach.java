package javaPractice.ch_04_control;

import java.util.Arrays;

public class Exam28_array_foreach {

	public static void main(String[] args) {
		//길이가 5인 배열 생성, 배열 길이 생략
		int[] a = new int[] {10,20,4,25,18};
		
		//길이가 7인 배열 생성, new int[] 생략가능 
		int[] b = {10,20,4,25,18};
		
		//for문으로 배열 초기화
		int[] c = new int[10];
		for (int i = 0; i < c.length; i++) {
			c[i] = i;
		}
		//for문을 이용한 출력
		System.out.println(c.length);
		for (int i = 0; i < c.length; i++) {
			System.out.print(c[i]);
		}
		
		//foreach문을 이용한 출력
		System.out.println();
		for (int d : c) {
			System.out.println(d);
		}
		
		System.out.println();
		System.out.println(Arrays.toString(c));
		//Arrays.toString() 매서드 이용

	}

}
