package javaPractice.ch_04_control;

import java.util.Scanner;

public class Exam11_switch {

	public static void main(String[] args) {
		//문제2
		//사용자에게 성적을 입력받아 switch문을 사용해서 학점을 출력하는 코드를 완성하세요 단,입력은 0 ~ 100까지 입력이 된다는것을 가정합니다
		//기준 : A : 90 ~ 100, B : 80 ~ 89, C : 70 ~ 79, D : 60 ~ 69, F : 0 ~ 59
		Scanner input = new Scanner(System.in);
		System.out.print("성적을 입력하세요>>");
		int num = input.nextInt();
		num = num / 10 * 10;
		switch (num) {
		case 90:
			System.out.println("A");
			break;
		case 80:
			System.out.println("B");
			break;
		case 70:
			System.out.println("C");
			break;
		case 60:
			System.out.println("D");
			break;
		default:
			System.out.println("F");
		}
		input.close();
	}

}
