package javaPractice.ch_04_control;

import java.util.Random;
import java.util.Scanner;

public class Exam38_random {

	public static void main(String[] args) {
		//int nextInt(int n) int타입의 0 ~ 매개값까지의 난수를 리턴합니다
		//프로그램이 가지고 있는 정수를 사용자가 알아맞히는 게임
		//1) 1부터 1000 사이의 정수 하나를 생성한다
		//2) 사용자가 답을 추측하여 입력한다
		//3) 정답이 아닐 경우 정답이 입력한 값보다 큰지 혹은 작은지 알려준다
		//4) 정답일 경우, 성공 메시지 및 시도 횟수 출력할것                                                                                  
		Scanner input = new Scanner(System.in);
		Random random = new Random();
		int answer = random.nextInt(999) + 1;
		int count = 0;
		while (true) {
			count++;
			System.out.print("정수를 입력하시오>> ");
			int num = input.nextInt();
			if(answer > num) {
				System.out.println("제시한 정수가 낮습니다");
			}
			else if(answer < num) {
				System.out.println("제시한 정수가 높습니다");
			}
			else {
				System.out.println("정답입니다 ! 시도횟수 : " + count);
				break;
			}
		}
		input.close();


	}

}
