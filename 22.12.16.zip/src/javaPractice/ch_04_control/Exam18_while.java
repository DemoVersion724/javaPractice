package javaPractice.ch_04_control;

public class Exam18_while {

	public static void main(String[] args) {
		//for문을 while문으로 변경
		int num = 0;
		int sum = 0;
		//for문
		for (num = 1; num <= 10; num++) {
			sum += num;
		}
		System.out.println("1부터 10까지의 합은" + sum + "입니다");
		//while문
		while (num <= 10) {
			sum += num;
			num++;
		}
		System.out.println("1부터 10까지의 합은" + sum + "입니다");
	
	}

}
