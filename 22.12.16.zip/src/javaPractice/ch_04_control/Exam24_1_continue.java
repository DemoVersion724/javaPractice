package javaPractice.ch_04_control;

public class Exam24_1_continue {

	public static void main(String[] args) {
		//continue문은 전체 반복 중에 특정조건을 만족하는 경우를 제외하고자 할 때 유용
		// 0- 100까지의 홀수 만 더함
		int total = 0;
		int num;
		for (num = 0; num <= 100; num++) {
			if(num % 2 ==0) {
				continue;
			}
			total += num;
//			if(num % 2 ==1) {
//				total += num;
//			}
		}
		System.out.println("1부터 100까지의 홀수의 합은 " + total + "입니다");
	}

}
