package javaPractice.ch_04_control;

public class Exam16_for {

	public static void main(String[] args) {
		//시스템을 최대한 적게 사용하는 알고리즘을 구현해내는것
		//문제1
		//for문을 이용해서 1부터 100까지의 정수 중에서 3의 배수의 총합을 구하는 코드를 작성해보시오
		int n = 0;
		for (int i = 3; i <= 100; i+=3) {
			n += i;
			}
		System.out.println("3의 배수의 합 : " + n);
		
		//문제2
		//for문을 이용하여 다음과 같이 *을 좌측배열 계단식으로 출력하는 코드를 작성하시오
		for (int i = 1; i <= 4; i++) {
			for (int j = 1; j <= i; j++) {
				System.out.print("*");
			}
			System.out.println();
		}
		
		
		//문제3
		//for문을 이용하여 다음과 같이 *을 우측배열 계단식으로 출력하는 코드를 작성하시오
		for (int i = 1; i <= 4; i++) {
			for (int j = 1; j <= (4 - i); j++) {
				System.out.print(" ");
			}
			for (int j = 1; j <= i; j++) {
				System.out.print("*");
			}
			System.out.println();
		}
	
		
		
		
		
		
	}

}
