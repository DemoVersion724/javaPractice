package javaPractice.ch_04_control;

public class Exam02_if_else {

	public static void main(String[] args) {
		int age = 15;
		if (age > 19) {
			System.out.println("성인입니다");
			System.out.println("성인요금이 적용됩니다");
		}
		else { //위의 조건식이 거짓일때만 적용
			System.out.println("청소년입니다");
			System.out.println("청소년 요금이 적용됩니다");
		}
		System.out.println("결제를 진행해주세요");
		
		//삼항연산자로 변경
		System.out.println(age > 19 ? "성인입니다 \n성인요금이 적용됩니다" : "청소년입니다 \n청소년 요금이 적용됩니다");
	}

}
