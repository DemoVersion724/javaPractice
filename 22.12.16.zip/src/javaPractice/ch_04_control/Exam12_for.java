package javaPractice.ch_04_control;

public class Exam12_for {

	public static void main(String[] args) {
		int sum = 0;
		for (int i = 1; i <= 10; i++) {
			System.out.println("i = " + i + ", sum = " + (sum += i));
		}
	}

}
