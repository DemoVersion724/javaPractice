package javaPractice.ch_04_control;

public class Exam01_if {

	public static void main(String[] args) {
		//조건문
		int a = 3;
		if (a > 3) { // if(조건식)
			System.out.println("a는 3보다 큽니다"); //조건식이 참일 때 실행
		} //if 구문의 끝
		System.out.println("검사가 끝났습니다");

	}

}
