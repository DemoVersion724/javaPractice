package javaPractice.ch_08_overriding;

public class overriding05_objectClass {

	public static void main(String[] args) {
		/*object class : 모든 클래스의 조상인 클래스 입니다 따라서 모든 클래스는 Object 클래스를 자동으로 상속하기 떄문에
		Object 클래스 내부에 정의 된 멤버들을 사용합니다 ex)toString(), equals()	
		상속 관계에 있는 클래스에서 반드시 상위 클래스의 생성자를 호출해야 되는 규칙도 결국에는 Object 클래스까지 거슬러 올라갑니다*/
	}

}
