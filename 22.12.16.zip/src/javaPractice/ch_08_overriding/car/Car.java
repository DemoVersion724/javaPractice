package javaPractice.ch_08_overriding.car;

/*속성 : 제조사(maker), 모델이름(model), 색상(color), 현재속도(curSpeed)
행위 : 가속(speedUp), 감속(speedDown)
1. 이 속성과 행위 설명을 바탕으로 하는 Car클래스를 정의 하라 단 가속과 감속의 결과는 curSpeed와 연동되어야 한다
2. 정의한 Car클래스에 파라미터로 모든 필드를 초기화 하는 생성자를 추가하고, 속성이 다른 인스턴스 세 개를 생성하라
3. Car 클래스를 상속받는 SportCar 클래스를 정의하고, 가속과 감속 매서드를 스포츠 카에 맞게 오버라이딩 하라*/

public class Car {
	private String maker, model, color; //제조사, 모델이름, 색상
	int curSpeed; //현재속도
	
	public Car(String maker, String model, String color, int curSpeed) {
		this.maker = maker;
		this.model = model;
		this.color = color;
		this.curSpeed = curSpeed;
	}
	public void speedUp() {
		this.curSpeed++;
	}
	public void speedDown() {
		this.curSpeed--;
	}
}
