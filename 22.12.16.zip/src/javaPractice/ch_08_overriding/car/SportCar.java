package javaPractice.ch_08_overriding.car;

public class SportCar extends Car{
	public SportCar(String maker, String model, String color, int curSpeed) {
		super(maker, model, color, curSpeed);
	}

	@Override
	public void speedUp() {
		this.curSpeed += 10;
	}

	@Override
	public void speedDown() {
		this.curSpeed -= 10;
	}

}
