package javaPractice.ch_08_overriding.car;

public class Test{

	public static void main(String[] args) {
		Car car1 = new Car("현대","제네시스","black",55);
		Car car2 = new Car("기아","K5","red",100);
		Car car3 = new Car("쌍용","렉스턴","grey",88);
		
		car1.speedUp();
		car2.speedUp();
		car3.speedDown();
		
		System.out.println(car1.curSpeed);
		System.out.println(car2.curSpeed);
		System.out.println(car3.curSpeed);
	}

}
