package javaPractice.ch_08_overriding;

class MyParent{
	void pDisplay() {
		System.out.println("Super : Parent's Display");
	}
}

class MyChild extends MyParent{
	//상위 클래스의 메서드를 재정의한다
	@Override
	void pDisplay() {
		//은닉된 상위 클래스의 메서드를 super로 호출한다
		super.pDisplay();
		System.out.println("Sub Class : Parent's Display");
	}
	void cDisplay() {
		System.out.println("Sub Class : Parent's Display");
	}
}

public class overriding03 {

	public static void main(String[] args) {
		MyChild c = new MyChild();
		c.pDisplay(); //재정의 된 하위 클래스의 메서드를 호툴한다
		//Super : Parent's Display
		//Sub Class : Parent's Display
	}

}
