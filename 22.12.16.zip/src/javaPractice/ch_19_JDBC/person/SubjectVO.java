package javaPractice.ch_19_JDBC.person;

public class SubjectVO {
	private int code; //과목코드
	private String subjectName; //과목명
	
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public String getSubjectName() {
		return subjectName;
	}
	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}
	
	@Override
	public String toString() {
		return "SubjectVO{" + "subjectName : " + subjectName + "(" + code + ")" + "}" ;
	}
	
}
