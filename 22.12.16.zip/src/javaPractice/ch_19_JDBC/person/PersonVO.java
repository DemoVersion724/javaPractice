package javaPractice.ch_19_JDBC.person;

public class PersonVO {
	private String name; // 이름
	private String phoneNumber; // 전화번호
	private String memo; // 메모
	private int studentNumber; //학번
	
	public PersonVO() {}
	
	public PersonVO(String name, String phoneNumber, String memo, int studentNumber) {
		this.name = name;
		this.phoneNumber = phoneNumber;
		this.memo = memo;
		this.studentNumber = studentNumber;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getMemo() {
		return memo;
	}
	public void setMemo(String memo) {
		this.memo = memo;
	}
	public int getStudentNumber() {
		return studentNumber;
	}
	public void setStudentNumber(int studentNumber) {
		this.studentNumber = studentNumber;
	}
	
	@Override
	public String toString() {
		return "PersonVO{" + "이름 : " + name + ", 전화번호 : " + phoneNumber + ", 메모 : " + memo + ", 학번 = " + studentNumber + "}" ;
	}
	
	
}