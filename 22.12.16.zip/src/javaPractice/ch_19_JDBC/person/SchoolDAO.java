package javaPractice.ch_19_JDBC.person;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;


public class SchoolDAO {
	private Connection connection = null;
	
	SchoolDAO() {
		getConnection();
	}
	
	private void getConnection() { //디비연결
		try {
			String url = "jdbc:mariadb://localhost:3308/sample_java"; //db url
			String user = "root"; //db user
			String password = "4517"; //db password
			try {
				Class.forName("org.mariadb.jdbc.Driver");
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
			this.connection = DriverManager.getConnection(url, user, password);
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
	//학생 추가 
	//동일한 학번 있는지
	public boolean isPerson(int studentNumber) { 
		int res = 0;
		
		try {
			String sql = "SELECT COUNT(*) AS cnt FROM school WHERE studentNumber = '" + studentNumber + "'";
			Statement statement = connection.createStatement();
			ResultSet resultSet = statement.executeQuery(sql);
			resultSet.next();
			res = resultSet.getInt("cnt");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return res !=0 ? true : false;
	}
	//학생INSERT
		public boolean insertPerson(PersonVO PersonVO) {
			Statement statement = null;	
			if(isPerson(PersonVO.getStudentNumber())) {
				System.out.println(PersonVO.getStudentNumber() + "은 이미 존재하는 학번입니다.");
				return false;
			}
			int upd = 0;
			try {
				String sql = String.format("INSERT INTO school VALUES ('%s', '%s', '%s', %d)"
										, PersonVO.getName(), PersonVO.getPhoneNumber(), PersonVO.getMemo()
										, PersonVO.getStudentNumber());
				statement = connection.createStatement();
				upd = statement.executeUpdate(sql);
			} catch (Exception e) {
				e.printStackTrace();
			}
			finally {
					try {
						if(statement != null) {
							statement.close();
						}
					} catch (SQLException e) {
						e.printStackTrace();
					}
			}
			boolean res = (upd == 0) ? false : true;
			return res;
		}
		
		//학생DElETE
		public boolean deletePerson(int studentNumber) {
			Statement statement = null;	
			if(!isPerson(studentNumber)) {
				System.out.println(studentNumber + "은 존재하지않는 학번입니다.");
				return false;
			}
			int upd = 0;
			try {
				String sql = String.format("DELETE FROM school WHERE studentNumber = '" + studentNumber + "'");
				statement = connection.createStatement();
				upd = statement.executeUpdate(sql);
			} catch (Exception e) {
				e.printStackTrace();
			}
			finally {
					try {
						if(statement != null) {
							statement.close();
						}
					} catch (SQLException e) {
						e.printStackTrace();
					}
			}
			boolean res = (upd == 0) ? false : true;
			return res;
		}
		
		//수강신청
		//과목코드 가져오기
		public SubjectVO selectSubject(int studentNumber) {
			Statement statement = null;
			SubjectVO subjectVO = null;
			
			if(!isPerson(studentNumber)) {
				System.out.println(studentNumber + "은 존재하지않는 학번입니다.");
			}
			else {
					try {
						String sql = "SELECT * FROM subject";
						statement = connection.createStatement();
						ResultSet resultSet = statement.executeQuery(sql);
						
						System.out.println("StudentList");
						//int num = 1;
						while(resultSet.next()) {
							//System.out.print(num + ". ");
							System.out.print(resultSet.getInt(1) + " : ");
							System.out.println(resultSet.getString(2));
							//num++;
						}
						
					} catch (Exception e) {
						e.printStackTrace();
					} finally {
						try {
							if(statement != null) {
								statement.close();
							}
						} catch (SQLException e) {
							e.printStackTrace();
						}
					}
			}
			return subjectVO;
		}
		
		public PersonVO getPerson(int studentNumber) {
			PersonVO personVO = new PersonVO(); 
			String sql = "SELECT * FROM school WHERE studentNumber =" + studentNumber;
			try {
				PreparedStatement statement = null;
				statement = connection.prepareStatement(sql);
				ResultSet resultSet = statement.executeQuery();
				if(resultSet.next()) {
					personVO.setStudentNumber(resultSet.getInt("studentNumber"));
					personVO.setPhoneNumber(resultSet.getString("phoneNumber"));
					personVO.setMemo(resultSet.getString("memo"));
					personVO.setName(resultSet.getString("name"));
				}
			} catch (Exception e) {

			}
			return personVO;
		}
		
		public SubjectVO getSubject(int subjectName) {
			SubjectVO subjectVO = new SubjectVO(); 
			String sql = "SELECT * FROM subject WHERE subjectName =" + subjectName;
			try {
				PreparedStatement statement = null;
				statement = connection.prepareStatement(sql);
				ResultSet resultSet = statement.executeQuery();
				if(resultSet.next()) {
					subjectVO.setSubjectName(resultSet.getString("subjectName"));
				}
			} catch (Exception e) {

			}
			return subjectVO;
		}
		
		//과목입력코드받기
		public boolean enrolment(int studentNumber) {
//			Statement statement = null;
			//SubjectVO subjectVO, PersonVO personVO, StudentVO studentVO
			PreparedStatement statement = null;
			//SubjectVO subjectVO = null;
			
			//SubjectVO subjectVO = getSubject();
			PersonVO personVO = getPerson(studentNumber);  
			StudentVO studentVO = new StudentVO();
			
			int upd = 0;
			try {
				String sql;
				sql = "INSERT INTO student(`name`,`phoneNumber`,`studentNumber`,`code`,`subjectName`,`score`) VALUES (?, ?, ?, ?, ?, 0)";
//				sql = "INSERT INTO student(`name`,`phoneNumber`,`studentNumber`,`code`,`subjectName`,`score`)"
//						+ " VALUES (personVO.getName(), personVO.getPhoneNumber(), personVO.getStudentNumber(), subjectVO.getCode(),"
//						+ " subjectVO.getSubjectName(), 0)";
				//statement = connection.createStatement();
				statement = connection.prepareStatement(sql);
				statement.setString(1, personVO.getName());
				System.out.println(personVO.getName());
				statement.setString(2, personVO.getPhoneNumber());
				statement.setInt(3, personVO.getStudentNumber());
				statement.setInt(4, subjectVO.getCode());
				statement.setString(5, subjectVO.getSubjectName());
				statement.setInt(6, studentVO.getScore());
				upd = statement.executeUpdate();
			} catch (Exception e) {
				e.printStackTrace();
			}	finally {
					try {
						if(statement != null) {
							statement.close();
						}
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
			boolean res = (upd == 0 ) ? false : true;
			return res;
			}
		
		
		//성적입력
		
		//정보조회
		//개별학생정보
		public PersonVO selectOne(int studentNumber) {
			Statement statement = null;
			PersonVO personVO = null;
			try {
				String sql = "SELECT * FROM school WHERE studentNumber = '" + studentNumber + "'";
				statement = connection.createStatement();
				ResultSet resultSet = statement.executeQuery(sql);
				
				if(resultSet.next()) {
					personVO = new PersonVO();
					personVO.setName(resultSet.getString("Name"));
					personVO.setPhoneNumber(resultSet.getString("phoneNumber"));
					personVO.setMemo(resultSet.getString("memo"));
					personVO.setStudentNumber(resultSet.getInt("studentNumber"));
				}
				
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					if(statement != null) {
						statement.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			return personVO;
		}
		
		//전체정보전달
		public ArrayList<PersonVO> selectAll(){
			Statement statement = null;
			ArrayList<PersonVO> list = new ArrayList<>();
			try {
				String sql = "SELECT * FROM school";
				statement = connection.createStatement();
				ResultSet resultSet = statement.executeQuery(sql);
				while(resultSet.next()){
					PersonVO personVO = new PersonVO(resultSet.getString("name"), resultSet.getString("phoneNumber")
										,resultSet.getString("memo"), resultSet.getInt("studentNumber"));
					list.add(personVO);
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					if(statement != null) {
						statement.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			return list;
		}
		
		//수강과목관리
		//과목INSERT
		public boolean isSubject(int code) { 
			int res = 0;
			try {
				String sql = "SELECT COUNT(*) AS cnt FROM subject WHERE code = '" + code + "'";
				Statement statement = connection.createStatement();
				ResultSet resultSet = statement.executeQuery(sql);
				resultSet.next();
				res = resultSet.getInt("cnt");
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return res !=0 ? true : false;
		}
		public boolean insertSubject(SubjectVO subjectVO) {
			Statement statement = null;	
			if(isSubject(subjectVO.getCode())) {
				System.out.println(subjectVO.getCode() + "은 이미 존재하는 과목입니다.");
				return false;
			}
			int upd = 0;
				try {
					String sql = String.format("INSERT INTO subject VALUES (%d, '%s')"
											, subjectVO.getCode(), subjectVO.getSubjectName());					
					statement = connection.createStatement();
					upd = statement.executeUpdate(sql);
					} catch (Exception e) {
						e.printStackTrace();
					}
			finally {
					try {
							if(statement != null) {
								statement.close();
							}
						} catch (SQLException e) {
							e.printStackTrace();
							}
					}
					boolean res = (upd == 0) ? false : true;
					return res;
				}
		//과목DElETE
		public boolean deleteSubject(int code) {
			Statement statement = null;	
			int upd = 0;
			try {
				String sql = String.format("DELETE FROM subject WHERE code = '" + code + "'");
				statement = connection.createStatement();
				upd = statement.executeUpdate(sql);
			} catch (Exception e) {
				e.printStackTrace();
			}
			finally {
					try {
						if(statement != null) {
							statement.close();
						}
					} catch (SQLException e) {
						e.printStackTrace();
					}
			}
			boolean res = (upd == 0) ? false : true;
			return res;
		}
		
		
} //end SchoolDAO
