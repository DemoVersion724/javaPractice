package javaPractice.ch_19_JDBC.person;

public class StudentVO {
	
	private int score;

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}
	
}