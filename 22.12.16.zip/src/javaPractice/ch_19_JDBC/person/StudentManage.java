package javaPractice.ch_19_JDBC.person;

import java.util.ArrayList;
import java.util.Scanner;

import javaPractice.ch_19_JDBC.Account.Account;
import javaPractice.ch_19_JDBC.Book.Book;

public class StudentManage {
	
	private ArrayList<StudentVO> list;
	private Scanner input;
	private SchoolDAO SchoolDAO;
	
	public StudentManage() {
		list = new ArrayList<>();
		input = new Scanner(System.in);
		SchoolDAO = new SchoolDAO();
	}
	
//	StudentVO findStudentInform(int studentNumber) {
//		for (StudentVO student : list) {
//			if(student.getStudentNumber() == studentNumber) {
//				System.out.println("해당 학생의 정보는 다음과 같습니다");
//				System.out.println("이름 :" + student.getName());
//				System.out.println("전화번호 :" + student.getPhoneNumber());
//				System.out.println("메모 :" + student.getMemo());
//				System.out.println("학번 :" + student.getStudentNumber());
//				return student;
//			}
//		} return null;
//	}
	
	//학생 추가
	public void addStudent() {
		PersonVO personVO = new PersonVO();
		
		System.out.print("학생의 이름을 입력 하세요. >>>");
		personVO.setName(input.next());
		
		System.out.print("학생의 전화번호를 입력 하세요. >>>");
		personVO.setPhoneNumber(input.next());
		
		System.out.print("메모할 사항을 입력 하세요. >>>");
		personVO.setMemo(input.next());
		
		System.out.print("학생의 학번을 입력 하세요. >>>");
		personVO.setStudentNumber(input.nextInt());
		
		if(SchoolDAO.insertPerson(personVO)) {
			System.out.println("학생 등록에 성공 하였습니다");
		}
		else {
			System.out.println("학생 등록에 실패 하였습니다");
		}
	}
	
	//학생 삭제
	public void removeStudent() {
		System.out.print("학생의 학번을 입력 하세요. >>>");
		int studentNumber = input.nextInt(); // 학번 입력받음
		
		if(SchoolDAO.deletePerson(studentNumber)) { 
			System.out.println(studentNumber + "학번을 삭제 하였습니다");
		}
		else {
			System.out.println("학생 삭제에 실패 하였습니다");
		}
	}
	
	//수강신청
	public void addClass() {
		System.out.print("학생의 학번을 입력 하세요. >>>");
		int studentNumber = input.nextInt(); // 학번 입력받음
		SubjectVO subjectVO = new SubjectVO();
				
		SchoolDAO.selectSubject(studentNumber);
		System.out.print("과목코드를 입력해주세요 >>");
		subjectVO.setCode(input.nextInt());
		
		if(SchoolDAO.enrolment(studentNumber)) {
			
			System.out.println("수강신청이 완료 되었습니다");
		}
		else {
			System.out.println("수강신청에 실패하였습니다");
		}
		
		
	}
	
	//학생 정보 조회 메뉴
	public void informStudent() {
		System.out.println("메뉴를 선택 해 주세요. 1. 특정 학생만 / 2. 전체 학생");
		int menu = input.nextInt();
		switch(menu) {
		 case 1: // 특정 학생의 성적 정보
			 displayOne();
			 break;
		 case 2: // 전체 학생의 성적 정보
			 displayAll();
			 break;
		}
	}
	
	//특정학생 정보 조회
	public void displayOne() {
		System.out.print("학번 >> ");
		int studentNumber = input.nextInt();
		
		PersonVO personVO = SchoolDAO.selectOne(studentNumber);
		if(personVO != null) {
			System.out.println("이름 : " + personVO.getName() + ", 전화번호 : " + personVO.getPhoneNumber()
								+ ", 메모 : " + personVO.getMemo() + ", 학번 : " + personVO.getStudentNumber());
		}
		else {
			System.out.println("해당 학번이 존재하지 않습니다.");
		}
	}
	//학생정보 전체 조회
	public void displayAll() {
		ArrayList<PersonVO> list = SchoolDAO.selectAll();
		for (PersonVO personVO : list) {
			System.out.println(personVO);
		}
	}
	
	//수강과목 관리 메뉴
	public void updateSubject() {
		System.out.println("메뉴를 선택 해 주세요. 1. 과목추가 / 2. 과목삭제 / 3.메인메뉴로");
		int menu = input.nextInt();
		switch(menu) {
		 case 1: 
			 addSubject();
			 break;
		 case 2: 
			 removeSubject();
			 break;
		 case 3: 
			 System.out.println("수강과목 관리를 종료 합니다.");
			 break;
		}
	}
	
	//과목추가
	public void addSubject() {
		SubjectVO subjectVO = new SubjectVO();
		
		System.out.print("과목의 코드를 입력 하세요. >>>");
		subjectVO.setCode(input.nextInt());
		
		System.out.print("과목의 이름을 입력 하세요. >>>");
		subjectVO.setSubjectName(input.next());
		
		if(SchoolDAO.insertSubject(subjectVO)) {
			System.out.println("과목 등록에 성공 하였습니다");
		}
		else {
			System.out.println("과목 추가에 실패 하였습니다");
		}
	}
	//과목 삭제
	public void removeSubject() {
		System.out.print("과목의 코드를 입력 하세요. >>>");
		int code = input.nextInt();
			
		if(SchoolDAO.deleteSubject(code)) { 
			System.out.println(code + "과목을 삭제 하였습니다");
		}
		else {
			System.out.println("과목 삭제에 실패 하였습니다");
		}
	}

	


//	// 4. 성적 입력 메뉴
//	void setScore() {
//		System.out.println("학생의 학번을 입력 하세요. >>>");
//		int studentNumber = input.nextInt(); // 학번 입력받음
//		
//		Student newStudent = findStudentInform(studentNumber);
//		if(newStudent == null) { //만약 기본에 학생의 정보가 없다면
//			System.out.println("Error : 학생이 존재하지 않습니다!!!");
//			return; // 메소드 종료
//		}
//		
//		while(true) {
//			System.out.println("성적을 입력/수정할 과목을 선택하세요.");
////			System.out.println("성적을 입력/수정할 과목을 선택하세요. 1. JAVA / 2. PYTHON / 3. C / 4. 종료");
//			for(int i = 0; i < Student.getClassName().length; i++) {
//				System.out.println(i+1 + ". " + Student.getClassName()[i] + " / ");
//			}
//			System.out.println((Student.getClassName().length+1) + ". 종료 >>> ");
//			int classMenu = input.nextInt();
//			if(classMenu == Student.getClassName().length+1) { // 종료 체크
//				break; // While문 종료
//			}
//			if(!newStudent.getClassCheck()[classMenu-1]) {//미신청 체크
//				System.out.println(Student.getClassName()[classMenu-1] + "과목은 미신청 과목입니다!");
//				continue; // 미신청이기 때문에 처음으로 되돌아간다
//			}
//			System.out.println("성적을 입력하세요 >>>");
//			int score = input.nextInt();
//			if(score < 0 || score > 100) { // 성적이 0 - 100 까지인지 체크
//				System.out.println("Error : 성적은 0부터 100사이에 숫자만 입력해주세요");
//				continue; // 처음으로 돌아감
//			}
//			// 정상적인 괌고과 성적이 입력이 된 경우
//			newStudent.setClassScore(classMenu-1, score); // 해당 학생의 Score 를 업데이트 한다.
//			System.out.println(Student.getClassName()[classMenu-1] + "성적 입력이 완료 되었습니다."); // 출력
//		}
//	}
//
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}