package javaPractice.ch_19_JDBC.Account;

import java.util.ArrayList;
import java.util.Scanner;

//1차 패키지에 디비가 저장되도록 수정
/*
1.테이블 생성
2.연결 메서드 작업
1)디비 연결
getConnection()

2)계좌생성시
boolean insertAccount(Account account)

3)동일한 걔좌가 있는지
boolean isAccount(int id)

4)계좌정보 조회
Account selectOne(int id)
ArrayList<Account> selectAll()

5)입금, 출금 처리
boolean updateBalance(int id, long money, boolean flag)

6)서비스 종료시
void disConnect()
*/

public class AccountManager {
	private ArrayList<Account> list;
	private Scanner stdIn;
	private AccountDAO accountDAO;
	
	public AccountManager() {
		accountDAO = new AccountDAO();
		list = new ArrayList<Account>();
		stdIn = new Scanner(System.in); 
	}
	
	//디비 관련 시작
	public void disConnect() {
		accountDAO.disConnect(); //db연결 종료 메서드
	}
	
	//디비 종료
	public void makeAccount() { //계좌개설
		Account account = new Account();
		
		System.out.print("계좌번호 : ");
		account.setId(stdIn.nextInt());
		
		System.out.print("이름 : ");
		account.setName(stdIn.next());

		System.out.print("입금액 : ");
		account.setBalance(stdIn.nextLong());
		
		//list.add(account);
		
		//System.out.println("계좌가 개설되었습니다");
		//System.out.println(list.toString() + "\t");
		
		if(accountDAO.insertAccount(account)) {
			System.out.println("계좌가 개설 되었습니다");
		}
		else {
			System.out.println("계좌 생성에 실패했습니다");
		}
	}
	
	public void deposit() { //입금
		System.out.print("계좌번호: ");
		int id = stdIn.nextInt();
		
		System.out.print("입금액: ");
		long money = stdIn.nextLong();
		
		// 해당 계좌 찾기
		if(accountDAO.isAccoubt(id)) {
			accountDAO.updateBalance(id, money, true);
		}
		else {
			System.out.println("해당계좌가 존재하지않습니다");
		}
		
		// 해당 계좌 찾기
//		for(Account account : list) {
//			if(account.getId() == id) {// 동일한 계좌가 있다면.
//				account.setBalance(money + account.getBalance());
//				System.out.println("입금완료 되었습니다.");
//				return;
//			}
//		}
//		System.out.println("해당 계좌번호가 존재하지 않습니다.");

	}
	
	public void withdraw() { //출금
		System.out.print("계좌번호 : ");
		int id = stdIn.nextInt();
		
		System.out.print("출금액 : ");
		long money = stdIn.nextLong();
		
		if(accountDAO.isAccoubt(id)) {
			Account account = accountDAO.selectOne(id);
			if(account.getBalance() < money) {
				System.out.println("잔액이 부족합니다");
			}
			else {
				accountDAO.updateBalance(id, money, false);
				System.out.println("출금완료 되었습니다");
			}
			return;
		}
		else {
			System.out.println("해당계좌가 존재하지않습니다");
		}
		
		
		//해당 계좌 찾기
//		for (Account account : list) {
//			if(account.getId() == id) { //동일한 객체가 있다면
//				if(account.getBalance() < meney){
//					System.out.println("잔액이 부족합니다");
//				}
//				else {
//					account.setBalance(account.getBalance() - meney);
//					System.out.println("출금완료 되었습니다");
//				}
//				return;
//			}
//		}
//		System.out.println("해당 계좌번호가 존재하지 않습니다");
	}
	
	public void inquire(){ //잔액조회
		System.out.print("계좌번호 : ");
		int id = stdIn.nextInt();
		
		//해당 계좌 찾기
//		for (Account account : list) {
//			if(account.getId() == id) {
//				System.out.println(account.getId() + "\t" + account.getName() + "\t" + account.getBalance());
//				return;
//			}
//		}
//		System.out.println("해당 계좌번호가 존재하지 않습니다.");
		
		Account account = accountDAO.selectOne(id);
		if(account != null) {
			System.out.println(account.getId() + "\t" + account.getName() + "\t" + account.getBalance());
		}
		else {
			System.out.println("해당 계좌번호가 존재하지 않습니다.");
		}
		
	}
	
	public void display() { //출력
		ArrayList<Account> list = accountDAO.selectAll();
		for (Account account : list) {
			System.out.println(account.getId() + "\t" + account.getName() + "\t" + account.getBalance());
		}
	}
	
}
