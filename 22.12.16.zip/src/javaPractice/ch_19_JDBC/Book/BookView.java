package javaPractice.ch_19_JDBC.Book;

import java.util.Scanner;

public class BookView {
	
	private static void printMenu() {
		System.out.println("==============Menu=============");
		System.out.println("1.책등록");
		System.out.println("2.책검색");
		System.out.println("3.책대여");
		System.out.println("4.책반납");
		System.out.println("5.책 전체출력");
		System.out.println("6.종료");
		System.out.println();
	}

	public static void main(String[] args) {
		BookManager manager = new BookManager();
		Scanner input = new Scanner(System.in);
		
		while(true) {
			printMenu();
			System.out.print("선택 : ");
			int choice = input.nextInt();
			switch(choice) {
			case 1:
				manager.SingUp();
				break;
			case 2:
				manager.search();
				break;
			case 3:
				manager.rental();
				break;
			case 4:
				manager.returns();
				break;
			case 5:
				manager.displayAll();
				break;
			case 6:
				manager.disConnect();
				System.out.println("종료합니다.");
				input.close();
				return;
			default:
				System.out.println("잘못누르셨습니다. \n다시선택해주세요.");
				break;
			}
		}
	}

}
