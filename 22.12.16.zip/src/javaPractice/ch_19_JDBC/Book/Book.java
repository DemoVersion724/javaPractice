package javaPractice.ch_19_JDBC.Book;

public class Book {
	private int id; //책코드
	private String title; //책제목
	private String writer; //책작가
	private int count; //재고 숫자
	
	public Book() {}
	
	public Book(int id, String title, String writer, int count) {
		this.id = id;
		this.title = title;
		this.writer = writer;
		this.count = count;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getWriter() {
		return writer;
	}

	public void setWriter(String writer) {
		this.writer = writer;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}
	
	@Override
	public String toString() {
		return "Book{" + "id = " + id + ", title = " + title + ", writer = " + writer + ", count = " + count + "}" ;
	}
}
