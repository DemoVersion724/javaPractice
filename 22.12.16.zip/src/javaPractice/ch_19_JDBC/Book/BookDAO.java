package javaPractice.ch_19_JDBC.Book;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;


public class BookDAO {
	
	private Connection connection = null;
	
	BookDAO() {
		getConnection();
	}
	
	private void getConnection() { //디비연결
		try {
			String url = "jdbc:mariadb://localhost:3308/sample_java"; //db url
			String user = "root"; //db user
			String password = "4517"; //db password
			try {
				Class.forName("org.mariadb.jdbc.Driver");
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
			this.connection = DriverManager.getConnection(url, user, password);
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void disConnect() { //연결해제. 서비스 종료시에 사용
		try {
			if(connection != null) {
				connection.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	//동일한 ID 있는지
	public boolean isBook(int id) { 
		int res = 0;
		
		try {
			String sql = "SELECT COUNT(*) AS cnt FROM book WHERE id = '" + id + "'";
			Statement statement = connection.createStatement();
			ResultSet resultSet = statement.executeQuery(sql);
			resultSet.next();
			res = resultSet.getInt("cnt");
			//System.out.println(res);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return res !=0 ? true : false;
	}
	
	//INSERT book
	public boolean insertBook(Book book) {
		Statement statement = null;	
		if(isBook(book.getId())) {
			System.out.println(book.getId() + " 도서가 존재합니다.");
			return false;
		}
		
		int upd = 0;
		try {
			String sql = String.format("INSERT INTO book VALUES (%d, '%s', '%s', %d)"
					, book.getId(), book.getTitle(), book.getWriter(), book.getCount());
			//System.out.println(sql);
			statement = connection.createStatement();
			upd = statement.executeUpdate(sql);
		} catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			try {
				if(statement != null) {
					statement.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		boolean res = (upd == 0) ? false : true;
		return res;
	}
	
	//개별 bookID
	public Book selectOne(int id) {
		Statement statement = null;
		Book book = null;
		try {
			String sql = "SELECT * FROM book WHERE id = '" + id + "'";
			statement = connection.createStatement();
			ResultSet resultSet = statement.executeQuery(sql);
			
			if(resultSet.next()) {
				book = new Book();
				book.setId(resultSet.getInt("id"));
				book.setTitle(resultSet.getString("title"));
				book.setWriter(resultSet.getString("writer"));
				book.setCount(resultSet.getInt("count"));
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(statement != null) {
					statement.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return book;
	}
	
	//전체 정보 전달
	public ArrayList<Book> selectAll(){
		Statement statement = null;
		ArrayList<Book> list = new ArrayList<>();
		try {
			String sql = "SELECT * FROM book";
			statement = connection.createStatement();
			ResultSet resultSet = statement.executeQuery(sql);
			while(resultSet.next()){
				Book book = new Book(resultSet.getInt("id"), resultSet.getString("title"),resultSet.getString("writer"), resultSet.getInt("count"));
				list.add(book);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(statement != null) {
					statement.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}
	
	//대여 및 반납
	 public boolean updateRental(int id, int count, boolean fiag) {
		Statement statement = null;
		boolean res = false;
		int upd = 0;
		try {
			String sql;
			if(fiag) {
				sql = String.format(String.format("UPDATE book SET count = count + %d WHERE (id = %d)", count, id));
			}
			else {
				sql = String.format(String.format("UPDATE book SET count = count - %d WHERE (id = %d)", count, id));
			}
			statement = connection.createStatement();
			upd = statement.executeUpdate(sql);
		} catch (Exception e) {
			e.printStackTrace();
		}	finally {
				try {
					if(statement != null) {
						statement.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		res = (upd == 0 ) ? false : true;
		return res;
	}
	
}
