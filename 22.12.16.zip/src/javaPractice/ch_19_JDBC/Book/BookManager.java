package javaPractice.ch_19_JDBC.Book;

import java.util.ArrayList;
import java.util.Scanner;

public class BookManager {
	
	private ArrayList<Book> list;
	private Scanner input;
	private BookDAO bookDAO;
	
	public BookManager() {
		bookDAO = new BookDAO();
		list = new ArrayList<>();
		input = new Scanner(System.in);
	}
	
	//책등록
	public void SingUp() {
		Book book = new Book();
		
		System.out.print("코드 >> ");
		book.setId(input.nextInt());
		
		System.out.print("제목 >> ");
		book.setTitle(input.next());
		
		System.out.print("작가 >> ");
		book.setWriter(input.next());
		
		System.out.print("재고 숫자 >> ");
		book.setCount(input.nextInt());	
		
//		if(isBook(book.getId())) {
//			System.out.println(book.getId() + " 해당 도서가 존재합니다.");
//		}
//		else {
//			list.add(book);
//			System.out.println("책 등록이 완료 되었습니다");
//			System.out.println(list.toString());
//		}
		
		if(bookDAO.insertBook(book)) {
			System.out.println("책 등록이 완료되었습니다");
		}
		else {
			System.out.println("책 등록에 실패했습니다");
		}
		
	}
	//동일한 책 id 찾기
//	public boolean isBook(int id) {
//		for (Book book : list) {
//			if(book.getId() == id) return true;
//		}
//		return false;
//	}
	
	//책검색
	public void search() {
		
		System.out.println("검색할 책의 제목을 입력 하세요");
		System.out.print("제목 >> ");
		String title = input.next();
		
		ArrayList<Book> searchList = new ArrayList<>();
		for (Book titleList : list) {
			if(titleList.getTitle().contains(title)) {
				searchList.add(titleList);
			}
		}
		if(searchList.size() < 1) {
			System.out.println("해당 도서가 존재 하지 않습니다");
		}
		else {
			System.out.println("검색 된 책의 정보는 아래와 같습니다");
			for (Book b : searchList) {
				System.out.println(b);
			}
		}
	}
	
	//책대여
	public void rental() {
		System.out.print("코드 >> ");
		int id = input.nextInt();
		
		System.out.print("대여권수 >> ");
		int rentalNum = input.nextInt();
		
		//해당 책 찾기
//		for (Book book : list) {
//			if(book.getId() == id) { //동일한 객체가 있다면
//				if(book.getCount() < rentalNum){
//					System.out.println("책의 재고가 부족합니다");
//				}
//				else {
//					book.setCount(book.getCount() - rentalNum);
//					System.out.println(book.getTitle() + " 대여가 완료 되었습니다");
//				}
//				return;
//			}
//		}
//		System.out.println("해당 코드를 가진 책이 존재하지 않습니다");
		
		if(bookDAO.isBook(id)) {
			Book book = bookDAO.selectOne(id);
			if(book.getCount() < rentalNum) {
				System.out.println("책의 재고가 부족합니다");
			}
			else {
				bookDAO.updateRental(id, rentalNum, false);
				System.out.println(book.getTitle() + " 대여가 완료 되었습니다");
			}
			return;
		}
		else {
			System.out.println("해당 코드를 가진 책이 존재하지 않습니다");
		}
		
	}
	
	//책반납
	public void returns() {
		System.out.print("코드 >> ");
		int id = input.nextInt();
		
		System.out.print("대여권수 >> ");
		int rentalNum = input.nextInt();
		
//		for(Book book : list) {
//			if(book.getId() == id) {// 동일한 계좌가 있다면.
//				book.setCount(rentalNum + book.getCount());
//				System.out.println("반납 완료 되었습니다.");
//				return;
//			}
//		}
//		System.out.println("해당 코드를 가진 책이 존재하지 않습니다");
		
		if(bookDAO.isBook(id)) {
			bookDAO.updateRental(id, rentalNum, true);
		}
		else {
			System.out.println("해당 코드를 가진 책이 존재하지않습니다");
		}
	}
	
	//책전체 출력
	public void displayAll() {
		ArrayList<Book> list = bookDAO.selectAll();
		for (Book book : list) {
			System.out.println(book);
		}
	}
	
	public void disConnect() { //디비 종료
		bookDAO.disConnect(); //db연결 종료 메서드
	}
}
